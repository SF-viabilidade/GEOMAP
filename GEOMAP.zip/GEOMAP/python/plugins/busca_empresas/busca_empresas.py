import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from qgis.utils import iface

# Importa a sua interface (Repare que removemos o import resources)
from .interface_empresas import BuscaEmpresasDock

class BuscaEmpresasPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock_widget = None
        self.action = None

    def initGui(self):
        # 1. Pega o caminho real da pasta do plugin e carrega o ícone DIRETAMENTE
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'icon.png')
        
        # 2. Cria a Ação (Botão)
        self.action = QAction(QIcon(icon_path), "Busca de Empresas", self.iface.mainWindow())
        self.action.setObjectName("BuscaEmpresasAction")
        self.action.setCheckable(True)
        
        self.action.triggered.connect(self.run)

        # 3. Adiciona na Barra de Ferramentas e no Menu
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Busca de Empresas", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Busca de Empresas", self.action)
        
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

    def run(self):
        if not self.dock_widget:
            self.dock_widget = BuscaEmpresasDock(self.iface.mainWindow(), self.iface)
            self.dock_widget.visibilityChanged.connect(self.action.setChecked)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
            
        if self.action.isChecked():
            self.dock_widget.show()
        else:
            self.dock_widget.hide()