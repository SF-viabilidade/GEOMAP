def classFactory(iface):
    from .busca_empresas import BuscaEmpresasPlugin
    return BuscaEmpresasPlugin(iface)