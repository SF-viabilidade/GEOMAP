import unicodedata
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, 
                             QHeaderView, QAbstractItemView, QDialog, QComboBox, 
                             QMessageBox, QCheckBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QCursor

from qgis.core import (QgsProject, QgsFeatureRequest, QgsGeometry)
from qgis.gui import QgsMapTool
from qgis.utils import iface

def normalize_str(s):
    if not s: return ""
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) 
                   if unicodedata.category(c) != 'Mn').lower()

def get_camada_empresas():
    """Busca a camada das empresas, quer se chame MOBILIARIO ou vw_mobiliario no QGIS"""
    camadas = QgsProject.instance().mapLayersByName('MOBILIARIO')
    if not camadas:
        camadas = QgsProject.instance().mapLayersByName('vw_mobiliario')
    return camadas[0] if camadas else None

# ============================================================================
# FERRAMENTA DE MAPA: CLIQUE NO LOTE PARA ABRIR O POPUP
# ============================================================================
class FerramentaPopupEmpresas(QgsMapTool):
    def __init__(self, canvas, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.setCursor(QCursor(Qt.CrossCursor))

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        geom_ponto = QgsGeometry.fromPointXY(point)

        layer_imob = QgsProject.instance().mapLayersByName('IMOBILIARIO')
        camada_emp = get_camada_empresas()
        
        if not layer_imob or not camada_emp:
            self.iface.messageBar().pushMessage("Erro", "Camadas 'IMOBILIARIO' ou 'vw_mobiliario' nao encontradas.", level=2)
            return
            
        layer_imob = layer_imob[0]

        tol = self.canvas.mapUnitsPerPixel() * 2
        req_inicial = QgsFeatureRequest().setFilterRect(geom_ponto.buffer(tol, 5).boundingBox())
        
        geom_base = None
        for f in layer_imob.getFeatures(req_inicial):
            if f.geometry().intersects(geom_ponto):
                geom_base = f.geometry()
                break
                
        if not geom_base:
            return 

        req_lotes = QgsFeatureRequest().setFilterRect(geom_base.boundingBox())
        inscricoes_stack = []
        
        for f in layer_imob.getFeatures(req_lotes):
            intersecao = f.geometry().intersection(geom_base)
            if intersecao.area() > 0.5:
                val = f['inscricao']
                if val:
                    try: inscricoes_stack.append(str(int(float(val))))
                    except: pass

        if not inscricoes_stack:
            return 

        # 1. String para a busca no SQL (tudo junto)
        in_clause_sql = ", ".join(inscricoes_stack)
        
        # 2. String para exibição (Quebra de linha a cada 15 inscrições)
        chunks = [inscricoes_stack[i:i + 15] for i in range(0, len(inscricoes_stack), 15)]
        in_clause_display = "<br>".join([", ".join(chunk) for chunk in chunks])

        expr = f"to_int(\"fisico\") IN ({in_clause_sql})"
        req_emp = QgsFeatureRequest().setFilterExpression(expr)
        
        dados_empresas = []
        situacoes_unicas = set()
        
        for f in camada_emp.getFeatures(req_emp):
            fis = str(f['fisico']) if f['fisico'] else '-'
            ccm = str(f['ccm']) if f['ccm'] else '-'
            cnpj = str(f['cnpj_cpf']) if f['cnpj_cpf'] else '-'
            sit = str(f['situacao']) if f['situacao'] else '-'
            
            nfantasia = str(f['nome_fantasia']) if f['nome_fantasia'] else ''
            nome_oficial = str(f['nome']) if f['nome'] else '-'
            nome_final = nfantasia.strip() if nfantasia.strip() else nome_oficial
            
            rua_num = str(f['endereco']) if f['endereco'] else ''
            bairro = str(f['bairro']) if f['bairro'] else ''
            
            end_completo = f"{rua_num} - {bairro}".strip(" ,-")
            if not end_completo: end_completo = "-"
            
            dados_empresas.append({
                'fisico': fis, 'ccm': ccm, 'cnpj': cnpj, 'situacao': sit, 
                'nome': nome_final, 'endereco': end_completo
            })
            if sit != '-': situacoes_unicas.add(sit)

        self.abrir_janela_resultados(dados_empresas, situacoes_unicas, in_clause_display)

    def abrir_janela_resultados(self, dados_empresas, situacoes_unicas, inscricoes_base_html):
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Consulta Avancada de Mobiliario (Condominio/Lote)")
        dlg.resize(1000, 400) 
        layout = QVBoxLayout(dlg)

        # Atualizado para receber o HTML formatado com quebras e ativando WordWrap
        lbl_end = QLabel(f"<span style='font-size: 14px; color: #333;'><b>Inscricao(oes) Base:</b><br>{inscricoes_base_html}</span>")
        lbl_end.setWordWrap(True)
        layout.addWidget(lbl_end)

        header_layout = QHBoxLayout()
        lbl_count = QLabel(f"Total de empresas: {len(dados_empresas)}")
        lbl_count.setStyleSheet("font-weight: bold; font-size: 13px; color: #0055a4;")
        header_layout.addWidget(lbl_count)
        header_layout.addStretch()

        header_layout.addWidget(QLabel("Filtrar por Situacao:"))
        combo_filtro = QComboBox()
        combo_filtro.addItem("Todas")
        for s in sorted(list(situacoes_unicas)): combo_filtro.addItem(s)
        header_layout.addWidget(combo_filtro)
        layout.addLayout(header_layout)

        tabela = QTableWidget()
        tabela.setColumnCount(6)
        tabela.setHorizontalHeaderLabels(["Inscricao", "CCM", "CNPJ/CPF", "Situacao", "Nome/Razao Social", "Endereco Completo"])
        header = tabela.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(tabela)

        def preencher_tabela(filtro="Todas"):
            tabela.setSortingEnabled(False)
            tabela.setRowCount(0)
            visiveis = 0
            for d in dados_empresas:
                if filtro == "Todas" or d['situacao'] == filtro:
                    row = tabela.rowCount()
                    tabela.insertRow(row)
                    
                    item_fisico = QTableWidgetItem(); item_fisico.setData(Qt.EditRole, int(d['fisico']) if d['fisico'].isdigit() else d['fisico'])
                    item_ccm = QTableWidgetItem(); item_ccm.setData(Qt.EditRole, int(d['ccm']) if d['ccm'].isdigit() else d['ccm'])
                    
                    tabela.setItem(row, 0, item_fisico)
                    tabela.setItem(row, 1, item_ccm)
                    tabela.setItem(row, 2, QTableWidgetItem(d['cnpj']))
                    tabela.setItem(row, 3, QTableWidgetItem(d['situacao']))
                    tabela.setItem(row, 4, QTableWidgetItem(d['nome']))
                    tabela.setItem(row, 5, QTableWidgetItem(d['endereco']))
                    visiveis += 1
            tabela.setSortingEnabled(True)
            lbl_count.setText(f"Mostrando: {visiveis} de {len(dados_empresas)} empresa(s)")
            tabela.resizeColumnsToContents()

        preencher_tabela()
        combo_filtro.currentTextChanged.connect(preencher_tabela)
        dlg.exec_()

# ============================================================================
# CLASSE PRINCIPAL: DOCK WIDGET (BARRA LATERAL)
# ============================================================================
class BuscaEmpresasDock(QDockWidget):
    def __init__(self, parent, iface):
        super().__init__("Busca de Empresas (Mobiliario)", parent)
        self.iface = iface
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        self.ferramenta_popup = FerramentaPopupEmpresas(self.iface.mapCanvas(), self.iface)
        self.initUI()

    def initUI(self):
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)
        self.setWidget(widget)

        self.btn_ativar_popup = QPushButton(" Ativar Consulta por Clique (Mapa)")
        self.btn_ativar_popup.setStyleSheet("background-color: #0055a4; color: white; font-weight: bold; padding: 8px;")
        self.btn_ativar_popup.clicked.connect(self.ativar_ferramenta_mapa)
        layout.addWidget(self.btn_ativar_popup)

        layout.addWidget(QLabel("<b>Buscar na Base:</b>"))
        
        self.input_ccm = QLineEdit(); self.input_ccm.setPlaceholderText("CCM...")
        layout.addWidget(self.input_ccm)
        
        self.input_cnpj = QLineEdit(); self.input_cnpj.setPlaceholderText("CNPJ ou CPF...")
        layout.addWidget(self.input_cnpj)
        
        self.input_nome = QLineEdit(); self.input_nome.setPlaceholderText("Nome Fantasia ou Razao...")
        layout.addWidget(self.input_nome)

        self.input_endereco = QLineEdit(); self.input_endereco.setPlaceholderText("Rua ou Bairro...")
        layout.addWidget(self.input_endereco)

        self.cbx_exata = QCheckBox("Busca Exata (ignorar partes de palavras)")
        layout.addWidget(self.cbx_exata)

        h_btn = QHBoxLayout()
        self.btn_buscar = QPushButton("Buscar")
        self.btn_buscar.clicked.connect(self.buscar)
        self.btn_limpar = QPushButton("Limpar")
        self.btn_limpar.clicked.connect(self.limpar)
        h_btn.addWidget(self.btn_buscar)
        h_btn.addWidget(self.btn_limpar)
        layout.addLayout(h_btn)

        self.tabela = QTableWidget()
        self.tabela.setColumnCount(5)
        self.tabela.setHorizontalHeaderLabels(["CCM", "Nome", "Situacao", "Fisico", "Endereco"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        self.tabela.itemDoubleClicked.connect(self.zoom_para_empresa)
        layout.addWidget(self.tabela)

    def ativar_ferramenta_mapa(self):
        self.iface.mapCanvas().setMapTool(self.ferramenta_popup)
        self.iface.messageBar().pushMessage("Ferramenta Ativa", "Clique num imovel no mapa para ver as empresas.", level=0, duration=3)

    def buscar(self):
        camada_emp = get_camada_empresas()
        
        if not camada_emp:
            QMessageBox.warning(self, "Erro", "Camada de empresas (vw_mobiliario) nao encontrada!")
            return
            
        filtros = []
        ccm = self.input_ccm.text().strip()
        cnpj = self.input_cnpj.text().strip()
        nome = normalize_str(self.input_nome.text().strip())
        endereco = normalize_str(self.input_endereco.text().strip())
        exata = self.cbx_exata.isChecked()

        if ccm: 
            filtros.append(f"\"ccm\" ILIKE '{ccm}'" if exata else f"\"ccm\" ILIKE '%{ccm}%'")
        if cnpj: 
            filtros.append(f"\"cnpj_cpf\" ILIKE '{cnpj}'" if exata else f"\"cnpj_cpf\" ILIKE '%{cnpj}%'")
        if nome:
            if exata:
                filtros.append(f"(lower(\"nome_fantasia\") ILIKE '{nome}' OR lower(\"nome\") ILIKE '{nome}')")
            else:
                filtros.append(f"(lower(\"nome_fantasia\") ILIKE '%{nome}%' OR lower(\"nome\") ILIKE '%{nome}%')")
        if endereco:
            if exata:
                filtros.append(f"(lower(\"endereco\") ILIKE '{endereco}' OR lower(\"bairro\") ILIKE '{endereco}')")
            else:
                filtros.append(f"(lower(\"endereco\") ILIKE '%{endereco}%' OR lower(\"bairro\") ILIKE '%{endereco}%')")

        if not filtros:
            QMessageBox.information(self, "Aviso", "Preencha pelo menos um campo para buscar.")
            return

        expressao = " AND ".join(filtros)
        req = QgsFeatureRequest().setFilterExpression(expressao)
        
        self.tabela.setSortingEnabled(False)
        self.tabela.setRowCount(0)
        
        for f in camada_emp.getFeatures(req):
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            
            nfantasia = str(f['nome_fantasia']) if f['nome_fantasia'] else ''
            nome_oficial = str(f['nome']) if f['nome'] else '-'
            nome_final = nfantasia.strip() if nfantasia.strip() else nome_oficial
            
            rua_num = str(f['endereco']) if f['endereco'] else ''
            bairro = str(f['bairro']) if f['bairro'] else ''
            
            end_completo = f"{rua_num} - {bairro}".strip(" ,-")
            if not end_completo: end_completo = "-"
            
            fis_str = str(f['fisico']) if f['fisico'] else "-"
            
            item_ccm = QTableWidgetItem(); item_ccm.setData(Qt.EditRole, int(f['ccm']) if str(f['ccm']).isdigit() else str(f['ccm']))
            item_fisico = QTableWidgetItem(); item_fisico.setData(Qt.EditRole, int(float(fis_str)) if fis_str.replace('.','',1).isdigit() else fis_str)
            
            self.tabela.setItem(row, 0, item_ccm)
            self.tabela.setItem(row, 1, QTableWidgetItem(nome_final))
            self.tabela.setItem(row, 2, QTableWidgetItem(str(f['situacao'])))
            self.tabela.setItem(row, 3, item_fisico)
            self.tabela.setItem(row, 4, QTableWidgetItem(end_completo))

        self.tabela.setSortingEnabled(True)
        self.tabela.resizeColumnsToContents()
        
        if self.tabela.rowCount() == 0:
            QMessageBox.information(self, "Aviso", "Nenhuma empresa encontrada.")

    def limpar(self):
        self.input_ccm.clear()
        self.input_cnpj.clear()
        self.input_nome.clear()
        self.input_endereco.clear()
        self.cbx_exata.setChecked(False)
        self.tabela.setRowCount(0)

    def zoom_para_empresa(self, item):
        row = item.row()
        ccm = str(self.tabela.item(row, 0).text())
        
        camada = get_camada_empresas()
        if not camada: return
        
        req = QgsFeatureRequest().setFilterExpression(f"\"ccm\" = '{ccm}'")
        
        for f in camada.getFeatures(req):
            self.iface.mapCanvas().setExtent(f.geometry().buffer(20, 5).boundingBox())
            self.iface.mapCanvas().refresh()
            break