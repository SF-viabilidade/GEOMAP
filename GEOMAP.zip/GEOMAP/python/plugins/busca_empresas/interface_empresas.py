import unicodedata
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, 
                             QHeaderView, QAbstractItemView, QDialog, QComboBox, 
                             QMessageBox, QCheckBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QCursor

from qgis.core import (QgsProject, QgsFeatureRequest, QgsGeometry)
from qgis.gui import QgsMapTool
from qgis.utils import iface

def normalize_str(s):
    """Remove acentos e coloca em minúsculas."""
    if not s: return ""
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) 
                   if unicodedata.category(c) != 'Mn').lower()

# ============================================================================
# FERRAMENTA DE MAPA: CLIQUE NO LOTE PARA ABRIR O POPUP
# ============================================================================
class FerramentaPopupEmpresas(QgsMapTool):
    def __init__(self, canvas, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        # Muda o cursor para uma cruzeta para indicar que a ferramenta está ativa
        self.setCursor(QCursor(Qt.CrossCursor))

    def canvasReleaseEvent(self, event):
        # 1. Pega a coordenada clicada no mapa
        point = self.toMapCoordinates(event.pos())
        geom_ponto = QgsGeometry.fromPointXY(point)

        # 2. Verifica as camadas necessárias
        layer_imob = QgsProject.instance().mapLayersByName('IMOBILIARIO')
        camadas_emp = QgsProject.instance().mapLayersByName('MOBILIARIO')
        
        if not layer_imob or not camadas_emp:
            self.iface.messageBar().pushMessage("Erro", "Camadas 'IMOBILIARIO' ou 'MOBILIARIO' não encontradas.", level=2)
            return
            
        layer_imob = layer_imob[0]
        camada_emp = camadas_emp[0]

        # 3. Descobre o polígono exato que o rato tocou (o lote base)
        tol = self.canvas.mapUnitsPerPixel() * 2
        req_inicial = QgsFeatureRequest().setFilterRect(geom_ponto.buffer(tol, 5).boundingBox())
        
        geom_base = None
        for f in layer_imob.getFeatures(req_inicial):
            if f.geometry().intersects(geom_ponto):
                geom_base = f.geometry()
                break # Encontrou o polígono que foi clicado, para a busca
                
        if not geom_base:
            return # Clicou na rua ou fora de um lote, não faz nada

        # 4. Magia Espacial: Encontra APENAS as inscrições empilhadas (ignora vizinhos de muro)
        req_lotes = QgsFeatureRequest().setFilterRect(geom_base.boundingBox())
        inscricoes_stack = []
        
        for f in layer_imob.getFeatures(req_lotes):
            # Calcula a sobreposição geométrica. Vizinhos de muro têm área = 0.
            intersecao = f.geometry().intersection(geom_base)
            if intersecao.area() > 0.5:
                val = f['inscricao']
                if val:
                    try:
                        inscricoes_stack.append(str(int(float(val))))
                    except:
                        pass

        if not inscricoes_stack:
            return 

        # 5. Busca as empresas daquelas inscrições exatas
        in_clause = ", ".join(inscricoes_stack)
        expr = f"to_int(fisico) IN ({in_clause})"
        req_emp = QgsFeatureRequest().setFilterExpression(expr)
        
        dados_empresas = []
        situacoes_unicas = set()
        for f in camada_emp.getFeatures(req_emp):
            fis = str(f['fisico']) if f['fisico'] else '-'
            ccm = str(f['ccm']) if f['ccm'] else '-'
            cnpj = str(f['cnpj_cpf']) if f['cnpj_cpf'] else '-'
            sit = str(f['situacao']) if f['situacao'] else '-'
            nome = str(f['nome_fantasia']) if f['nome_fantasia'] and str(f['nome_fantasia']).strip() else (str(f['nome']) if f['nome'] else '-')
            
            dados_empresas.append({'fisico': fis, 'ccm': ccm, 'cnpj': cnpj, 'situacao': sit, 'nome': nome})
            if sit != '-': situacoes_unicas.add(sit)

        # 6. Abre a Janela Popup Avançada
        self.abrir_janela_resultados(dados_empresas, situacoes_unicas)

    def abrir_janela_resultados(self, dados_empresas, situacoes_unicas):
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Consulta Avançada de Mobiliário (Condomínio/Lote)")
        dlg.resize(850, 400)
        layout = QVBoxLayout(dlg)

        header_layout = QHBoxLayout()
        lbl_count = QLabel(f"Total de empresas: {len(dados_empresas)}")
        lbl_count.setStyleSheet("font-weight: bold; font-size: 13px; color: #0055a4;")
        header_layout.addWidget(lbl_count)
        header_layout.addStretch()

        header_layout.addWidget(QLabel("Filtrar por Situação:"))
        combo_filtro = QComboBox()
        combo_filtro.addItem("Todas")
        for s in sorted(list(situacoes_unicas)): combo_filtro.addItem(s)
        header_layout.addWidget(combo_filtro)
        layout.addLayout(header_layout)

        tabela = QTableWidget()
        tabela.setColumnCount(5)
        tabela.setHorizontalHeaderLabels(["Inscrição", "CCM", "CNPJ/CPF", "Situação", "Nome/Razão Social"])
        header = tabela.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(tabela)

        def preencher_tabela(filtro="Todas"):
            tabela.setSortingEnabled(False)
            tabela.setRowCount(0)
            visiveis = 0
            for d in dados_empresas:
                if filtro == "Todas" or d['situacao'] == filtro:
                    row = tabela.rowCount()
                    tabela.insertRow(row)
                    
                    item_fisico = QTableWidgetItem(); item_fisico.setData(Qt.EditRole, int(d['fisico']) if d['fisico'].isdigit() else d['fisico'])
                    item_ccm = QTableWidgetItem(); item_ccm.setData(Qt.EditRole, int(d['ccm']) if d['ccm'].isdigit() else d['ccm'])
                    
                    tabela.setItem(row, 0, item_fisico)
                    tabela.setItem(row, 1, item_ccm)
                    tabela.setItem(row, 2, QTableWidgetItem(d['cnpj']))
                    tabela.setItem(row, 3, QTableWidgetItem(d['situacao']))
                    tabela.setItem(row, 4, QTableWidgetItem(d['nome']))
                    visiveis += 1
            tabela.setSortingEnabled(True)
            lbl_count.setText(f"Mostrando: {visiveis} de {len(dados_empresas)} empresa(s)")
            tabela.resizeColumnsToContents()

        preencher_tabela()
        combo_filtro.currentTextChanged.connect(preencher_tabela)
        dlg.exec_()

# ============================================================================
# CLASSE PRINCIPAL: DOCK WIDGET (BARRA LATERAL)
# ============================================================================
class BuscaEmpresasDock(QDockWidget):
    def __init__(self, parent, iface):
        super().__init__("Busca de Empresas (Mobiliário)", parent)
        self.iface = iface
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        self.ferramenta_popup = FerramentaPopupEmpresas(self.iface.mapCanvas(), self.iface)

        self.initUI()

    def initUI(self):
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)
        self.setWidget(widget)

        # Botão para ativar a ferramenta do Popup
        self.btn_ativar_popup = QPushButton(" Ativar Consulta por Clique (Mapa)")
        self.btn_ativar_popup.setStyleSheet("background-color: #0055a4; color: white; font-weight: bold; padding: 8px;")
        self.btn_ativar_popup.clicked.connect(self.ativar_ferramenta_mapa)
        layout.addWidget(self.btn_ativar_popup)

        # Campos de Busca
        layout.addWidget(QLabel("<b>Buscar na Base:</b>"))
        
        self.input_ccm = QLineEdit(); self.input_ccm.setPlaceholderText("CCM...")
        layout.addWidget(self.input_ccm)
        
        self.input_cnpj = QLineEdit(); self.input_cnpj.setPlaceholderText("CNPJ ou CPF...")
        layout.addWidget(self.input_cnpj)
        
        self.input_nome = QLineEdit(); self.input_nome.setPlaceholderText("Nome Fantasia ou Razão...")
        layout.addWidget(self.input_nome)

        # Checkbox para Busca Exata
        self.cbx_exata = QCheckBox("Busca Exata (ignorar partes de palavras)")
        layout.addWidget(self.cbx_exata)

        # Botões Buscar / Limpar
        h_btn = QHBoxLayout()
        self.btn_buscar = QPushButton("Buscar")
        self.btn_buscar.clicked.connect(self.buscar)
        self.btn_limpar = QPushButton("Limpar")
        self.btn_limpar.clicked.connect(self.limpar)
        h_btn.addWidget(self.btn_buscar)
        h_btn.addWidget(self.btn_limpar)
        layout.addLayout(h_btn)

        # Tabela de Resultados
        self.tabela = QTableWidget()
        self.tabela.setColumnCount(4)
        self.tabela.setHorizontalHeaderLabels(["CCM", "Nome", "Situação", "Físico"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        # Duplo clique para dar Zoom na empresa
        self.tabela.itemDoubleClicked.connect(self.zoom_para_empresa)
        layout.addWidget(self.tabela)

    def ativar_ferramenta_mapa(self):
        self.iface.mapCanvas().setMapTool(self.ferramenta_popup)
        self.iface.messageBar().pushMessage("Ferramenta Ativa", "Clique num imóvel no mapa para ver as empresas.", level=0, duration=3)

    def buscar(self):
        camadas = QgsProject.instance().mapLayersByName('MOBILIARIO')
        if not camadas:
            QMessageBox.warning(self, "Erro", "Camada 'MOBILIARIO' não encontrada no painel!")
            return
        
        camada = camadas[0]
        filtros = []
        
        ccm = self.input_ccm.text().strip()
        cnpj = self.input_cnpj.text().strip()
        nome = normalize_str(self.input_nome.text().strip())
        
        # Verifica se a caixa de busca exata está marcada
        exata = self.cbx_exata.isChecked()

        if ccm: 
            if exata:
                filtros.append(f"\"ccm\" ILIKE '{ccm}'")
            else:
                filtros.append(f"\"ccm\" ILIKE '%{ccm}%'")
                
        if cnpj: 
            if exata:
                filtros.append(f"\"cnpj_cpf\" ILIKE '{cnpj}'")
            else:
                filtros.append(f"\"cnpj_cpf\" ILIKE '%{cnpj}%'")
                
        if nome:
            if exata:
                filtros.append(f"(lower(\"nome_fantasia\") ILIKE '{nome}' OR lower(\"nome\") ILIKE '{nome}')")
            else:
                filtros.append(f"(lower(\"nome_fantasia\") ILIKE '%{nome}%' OR lower(\"nome\") ILIKE '%{nome}%')")

        if not filtros:
            QMessageBox.information(self, "Aviso", "Preencha pelo menos um campo para buscar.")
            return

        expressao = " AND ".join(filtros)
        req = QgsFeatureRequest().setFilterExpression(expressao)
        
        self.tabela.setRowCount(0)
        for f in camada.getFeatures(req):
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            
            nome_final = str(f['nome_fantasia']) if f['nome_fantasia'] and str(f['nome_fantasia']).strip() else str(f['nome'])
            
            self.tabela.setItem(row, 0, QTableWidgetItem(str(f['ccm'])))
            self.tabela.setItem(row, 1, QTableWidgetItem(nome_final))
            self.tabela.setItem(row, 2, QTableWidgetItem(str(f['situacao'])))
            self.tabela.setItem(row, 3, QTableWidgetItem(str(f['fisico'])))

    def limpar(self):
        self.input_ccm.clear()
        self.input_cnpj.clear()
        self.input_nome.clear()
        self.cbx_exata.setChecked(False) # Desmarca a busca exata ao limpar
        self.tabela.setRowCount(0)

    def zoom_para_empresa(self, item):
        row = item.row()
        ccm = self.tabela.item(row, 0).text()
        
        camadas = QgsProject.instance().mapLayersByName('MOBILIARIO')
        if not camadas: return
        
        camada = camadas[0]
        req = QgsFeatureRequest().setFilterExpression(f"\"ccm\" = '{ccm}'")
        
        for f in camada.getFeatures(req):
            self.iface.mapCanvas().setExtent(f.geometry().buffer(20, 5).boundingBox())
            self.iface.mapCanvas().refresh()
            break