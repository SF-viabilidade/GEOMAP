import os
import shutil
import datetime
import getpass
from qgis.core import QgsProject
from qgis.gui import QgsDockWidget
from qgis.utils import iface
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QLabel, QTreeWidget, QTreeWidgetItem, 
                             QPushButton, QFileDialog, QMessageBox, QHeaderView)
from PyQt5.QtCore import Qt, QMetaObject, QCoreApplication, QUrl, pyqtSignal
from PyQt5.QtGui import QDesktopServices

# ============================================================================
# CLASSE AUXILIAR PARA ORDENAÇÃO CORRETA
# ============================================================================
class SortableTreeWidgetItem(QTreeWidgetItem):
    def __lt__(self, other):
        column = self.treeWidget().sortColumn()
        val1 = self.data(column, Qt.UserRole)
        val2 = other.data(column, Qt.UserRole)
        if val1 is not None and val2 is not None:
            return val1 < val2
        return super().__lt__(other)

# ============================================================================
# INTERFACE GRÁFICA
# ============================================================================
class Ui_DockWidget(object):
    def setupUi(self, DockWidget):
        DockWidget.setObjectName("DockWidget")
        DockWidget.resize(400, 550)
        DockWidget.setWindowTitle("Gestor de Documentos")
        
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        
        self.verticalLayout = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName("verticalLayout")
        
        # Label Info
        self.lbl_info = QLabel(self.dockWidgetContents)
        self.lbl_info.setStyleSheet("font-weight: bold; font-size: 14px; color: #2c3e50; margin-bottom: 5px;")
        self.lbl_info.setWordWrap(True)
        self.lbl_info.setAlignment(Qt.AlignCenter)
        self.verticalLayout.addWidget(self.lbl_info)
        
        # Tabela
        self.tree_files = QTreeWidget(self.dockWidgetContents)
        self.tree_files.setHeaderLabels(["Nome", "Data", "Tamanho"])
        self.tree_files.setSortingEnabled(True)
        self.tree_files.setRootIsDecorated(False)
        
        # Configuração de Colunas
        header = self.tree_files.header()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.resizeSection(0, 200) # Nome
        header.resizeSection(1, 110) # Data
        header.resizeSection(2, 70)  # Tamanho
        
        self.verticalLayout.addWidget(self.tree_files)
        
        # Botões
        self.btn_import = QPushButton("📂 Importar Documento", self.dockWidgetContents)
        self.btn_import.setStyleSheet("background-color: #27ae60; color: white; font-weight: bold; padding: 5px;")
        self.verticalLayout.addWidget(self.btn_import)
        
        # Botão DELETE (Admin)
        self.btn_delete = QPushButton("🗑️ Mover para Lixeira (Admin)", self.dockWidgetContents)
        self.btn_delete.setStyleSheet("background-color: #c0392b; color: white; font-weight: bold; padding: 5px;")
        self.verticalLayout.addWidget(self.btn_delete)
        
        # Botão ABRIR PASTA (Admin)
        self.btn_open_folder = QPushButton("💻 Abrir Pasta Local (Admin)", self.dockWidgetContents)
        self.verticalLayout.addWidget(self.btn_open_folder)
        
        self.btn_refresh = QPushButton("🔄 Atualizar Lista", self.dockWidgetContents)
        self.verticalLayout.addWidget(self.btn_refresh)
        
        DockWidget.setWidget(self.dockWidgetContents)
        QMetaObject.connectSlotsByName(DockWidget)

# ============================================================================
# LÓGICA DO PLUGIN
# ============================================================================
class GestorDocsDockWidget(QgsDockWidget, Ui_DockWidget):
    
    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        super(GestorDocsDockWidget, self).__init__(parent)
        self.setupUi(self)
        
        # --- CONFIGURAÇÃO GERAL ---
        self.root_dir = r"S:\geomap\geomap_imob\imobiliario_geomap"
        self.id_field = "inscricao"              
        
        # --- CONFIGURAÇÃO DE SEGURANÇA ---
        self.admin_users = ["hstevanatto", "vgmontagnoli"] 
        # ---------------------------------

        self.current_feature_id = None
        self.current_folder = None
        
        # Verifica Usuário
        current_user = getpass.getuser().lower()
        
        if current_user in self.admin_users:
            self.btn_delete.setVisible(True)
            self.btn_open_folder.setVisible(True)
            self.setWindowTitle(f"Gestor de Documentos (Admin: {current_user})")
        else:
            self.btn_delete.setVisible(False)
            self.btn_open_folder.setVisible(False)
            self.setWindowTitle(f"Gestor de Documentos (Leitura)")

        if not os.path.exists(self.root_dir):
            try:
                os.makedirs(self.root_dir)
            except Exception as e:
                self.lbl_info.setText(f"Erro de acesso: {str(e)}")

        # Conexões
        self.btn_import.clicked.connect(self.import_file)
        self.btn_delete.clicked.connect(self.delete_file)
        self.btn_open_folder.clicked.connect(self.open_folder_explorer)
        self.btn_refresh.clicked.connect(self.refresh_list)
        self.tree_files.itemDoubleClicked.connect(self.open_file)
        
        iface.mapCanvas().selectionChanged.connect(self.selection_changed)
        self.toggle_buttons(False)

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def toggle_buttons(self, state):
        self.btn_import.setEnabled(state)
        self.btn_delete.setEnabled(state) 
        self.btn_open_folder.setEnabled(state)
        self.btn_refresh.setEnabled(state)

    def selection_changed(self, layer=None):
        if not self.isVisible(): return

        layer = iface.activeLayer()
        if not layer or layer.selectedFeatureCount() != 1:
            self.lbl_info.setText("Selecione UM imóvel no mapa.")
            self.tree_files.clear()
            self.toggle_buttons(False)
            self.current_feature_id = None
            return

        feature = layer.selectedFeatures()[0]
        try:
            raw_id = feature[self.id_field]
            inscricao = str(raw_id) if raw_id is not None else ""
            safe_name = "".join([c for c in inscricao if c.isalnum() or c in (' ', '-', '_')]).strip()
            
            if not safe_name:
                self.lbl_info.setText("Inscrição inválida.")
                self.toggle_buttons(False)
                return

            self.current_feature_id = safe_name
            self.lbl_info.setText(f"Imóvel: {self.current_feature_id}")
            self.current_folder = os.path.join(self.root_dir, self.current_feature_id)
            self.refresh_list()
            self.toggle_buttons(True)
            
        except KeyError:
            self.lbl_info.setText(f"Campo '{self.id_field}' não encontrado.")
            self.toggle_buttons(False)

    def _human_readable_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"

    def refresh_list(self):
        self.tree_files.clear()
        if not self.current_folder: return

        if not os.path.exists(self.current_folder):
            item = QTreeWidgetItem(["[Pasta vazia]", "", ""])
            self.tree_files.addTopLevelItem(item)
            return

        try:
            with os.scandir(self.current_folder) as entries:
                items = []
                for entry in entries:
                    if entry.is_file():
                        try:
                            stats = entry.stat()
                            name = entry.name
                            ts = stats.st_mtime
                            date_obj = datetime.datetime.fromtimestamp(ts)
                            date_str = date_obj.strftime("%d/%m/%Y %H:%M")
                            size_bytes = stats.st_size
                            size_str = self._human_readable_size(size_bytes)
                            
                            item = SortableTreeWidgetItem([name, date_str, size_str])
                            item.setData(1, Qt.UserRole, ts)
                            item.setData(2, Qt.UserRole, size_bytes)
                            items.append(item)
                        except OSError:
                            continue
                self.tree_files.addTopLevelItems(items)
        except Exception as e:
            item = QTreeWidgetItem([f"Erro: {str(e)}", "", ""])
            self.tree_files.addTopLevelItem(item)

    def import_file(self):
        if not self.current_folder: return
        filename, _ = QFileDialog.getOpenFileName(self, "Selecionar Arquivo")
        if filename:
            try:
                if not os.path.exists(self.current_folder):
                    os.makedirs(self.current_folder)
                basename = os.path.basename(filename)
                shutil.copy2(filename, os.path.join(self.current_folder, basename))
                self.refresh_list()
                iface.messageBar().pushMessage("Sucesso", "Arquivo importado!", level=0)
            except Exception as e:
                QMessageBox.critical(self, "Erro", str(e))

    def delete_file(self):
        """
        Move o arquivo para uma pasta CENTRALIZADA de lixeira.
        """
        item = self.tree_files.currentItem()
        if not item:
            iface.messageBar().pushMessage("Aviso", "Selecione um arquivo para excluir.", level=1)
            return

        filename = item.text(0)
        if filename.startswith("["): return

        # Caminho original do arquivo
        src_path = os.path.join(self.current_folder, filename)
        
        # --- Lógica da Lixeira Centralizada ---
        # Define a pasta _LIXEIRA_GERAL na raiz do diretório principal
        central_trash_dir = os.path.join(self.root_dir, "_LIXEIRA_GERAL")
        
        # Monta um nome único para o arquivo na lixeira para saber de onde veio
        # Ex: 12345_Contrato_20231201_153000.pdf
        base, ext = os.path.splitext(filename)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Nome final: INSCRIÇÃO + NOME_ORIGINAL + DATA + EXTENSÃO
        new_filename = f"{self.current_feature_id}_{base}_{timestamp}{ext}"
        dst_path = os.path.join(central_trash_dir, new_filename)

        reply = QMessageBox.question(self, 'Confirmar Exclusão', 
                                     f'Deseja enviar "{filename}" para a LIXEIRA GERAL?',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            try:
                # Cria a pasta central se não existir
                if not os.path.exists(central_trash_dir):
                    os.makedirs(central_trash_dir)
                    # Opcional: Tenta ocultar a pasta no Windows para não atrapalhar
                    try:
                        import ctypes
                        ctypes.windll.kernel32.SetFileAttributesW(central_trash_dir, 0x02)
                    except: pass

                shutil.move(src_path, dst_path)
                
                self.refresh_list()
                iface.messageBar().pushMessage("Sucesso", f"Arquivo movido para _LIXEIRA_GERAL", level=0)
            
            except Exception as e:
                QMessageBox.critical(self, "Erro", f"Erro ao mover para lixeira central: {str(e)}")

    def open_file(self, item, column):
        filename = item.text(0)
        if filename.startswith("["): return
        path = os.path.join(self.current_folder, filename)
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def open_folder_explorer(self):
        if self.current_folder:
            if not os.path.exists(self.current_folder):
                try: os.makedirs(self.current_folder)
                except: pass
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.current_folder))