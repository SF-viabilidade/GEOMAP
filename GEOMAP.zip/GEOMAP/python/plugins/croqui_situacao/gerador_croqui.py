import os
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QIcon, QColor, QDesktopServices
from qgis.PyQt.QtWidgets import QDockWidget, QMessageBox, QAction, QFileDialog, QSizePolicy
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import (QgsProject, QgsPrintLayout, QgsReadWriteContext, 
                       QgsGeometry, QgsLayoutExporter, QgsLayoutObject)
from qgis.gui import QgsMapToolExtent, QgsMapCanvas, QgsMapToolPan

# Carrega a interface (.ui)
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'gerador_croqui_dialog_base.ui'))

class GeradorCroquiDock(QDockWidget, FORM_CLASS):
    def __init__(self, parent=None):
        super(GeradorCroquiDock, self).__init__(parent)
        self.setupUi(self)
        self.canvas_ref = None # Referência para o mapa interativo

    def resizeEvent(self, event):
        """
        Força a altura do mini-mapa a seguir a proporção exata da folha (190.2 x 201.75)
        """
        super().resizeEvent(event)
        if self.canvas_ref:
            w = self.groupBoxPreview.contentsRect().width() - 4 
            if w > 10:
                h = int(w * (201.75 / 190.2))
                self.canvas_ref.setFixedHeight(h)

class GeradorCroquiPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.geometria_referencia = None
        self.action = None
        self.dock = None
        self.preview_canvas = None
        self.pan_tool = None 

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "Gerador de Croqui Valinhos", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Valinhos", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Valinhos", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dock:
            self.iface.removeDockWidget(self.dock)

    def ativar_ferramenta_desenho(self):
        self.tool = QgsMapToolExtent(self.canvas)
        def definir_geometria(extent):
            self.geometria_referencia = QgsGeometry.fromRect(extent)
            self.iface.mapCanvas().unsetMapTool(self.tool)
            self.atualizar_preview()
            
        self.tool.extentChanged.connect(definir_geometria)
        self.iface.mapCanvas().setMapTool(self.tool)

    def atualizar_preview(self):
        if not self.geometria_referencia or not self.preview_canvas:
            return

        rect = self.geometria_referencia.boundingBox()
        if rect.width() == 0 and rect.height() == 0:
            rect.grow(10.0)

        margem_fator = 1.0 + (self.dock.mSpinBoxMargem.value() / 100.0)
        rect.scale(margem_fator)

        self.preview_canvas.setLayers(self.canvas.mapSettings().layers())
        self.preview_canvas.setExtent(rect)
        self.preview_canvas.refresh()

    def run(self):
        if not self.dock:
            self.dock = GeradorCroquiDock(self.iface.mainWindow())
            
            # --- Configuração do Mini Mapa ---
            self.preview_canvas = QgsMapCanvas(self.dock)
            self.preview_canvas.setCanvasColor(QColor("white"))
            self.preview_canvas.enableAntiAliasing(True)
            self.preview_canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            
            self.dock.canvas_ref = self.preview_canvas
            
            self.preview_canvas.setDestinationCrs(self.canvas.mapSettings().destinationCrs())
            self.preview_canvas.setProject(QgsProject.instance())
            
            self.preview_canvas.setWheelFactor(2)
            self.pan_tool = QgsMapToolPan(self.preview_canvas)
            self.preview_canvas.setMapTool(self.pan_tool)
            
            self.dock.verticalLayoutPreview.addWidget(self.preview_canvas)
            
            self.dock.btnDesenharRef.clicked.connect(self.ativar_ferramenta_desenho)
            self.dock.btnGerar.clicked.connect(self.processar_layout)
            self.dock.mSpinBoxMargem.valueChanged.connect(self.atualizar_preview)
            
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        
        self.geometria_referencia = None 
        if self.preview_canvas:
            self.preview_canvas.setLayers([])
            self.preview_canvas.refresh()
            
        self.dock.show()

    def processar_layout(self):
        extent_atual = self.preview_canvas.extent()
        
        if extent_atual.isEmpty():
            QMessageBox.warning(self.dock, "Atenção", "Por favor, clique em 'Definir Centro no Mapa' e desenhe a área antes de gerar.")
            return

        nome_arquivo_sugerido = "Croqui_Situacao.pdf"
        caminho_pdf, _ = QFileDialog.getSaveFileName(
            self.dock, "Salvar Croqui em PDF", nome_arquivo_sugerido, "PDF files (*.pdf)"
        )

        if not caminho_pdf:
            return

        project = QgsProject.instance()
        layout = QgsPrintLayout(project)
        path_qpt = os.path.join(os.path.dirname(__file__), 'croqui_situacao.qpt')
        
        try:
            with open(path_qpt, 'rt', encoding='utf-8') as f:
                xml = f.read()
        except Exception as e:
            QMessageBox.critical(self.dock, "Erro", f"Não foi possível ler o template: {str(e)}")
            return
        
        doc = QDomDocument()
        doc.setContent(xml)
        layout.loadFromTemplate(doc, QgsReadWriteContext())

        total_layouts = len(project.layoutManager().printLayouts())
        layout.setName(f"Croqui_{total_layouts + 1}")
        project.layoutManager().addLayout(layout)

        if layout.atlas().enabled():
            layout.atlas().setEnabled(False)

        mapa = layout.itemById("Mapa 1")
        if mapa:
            mapa.setKeepLayerSet(False)
            mapa.setLayers(self.canvas.mapSettings().layers())

            # A CHAVE DO SUCESSO: Desliga o controle por Atlas no item específico!
            # Isso impede o mapa de crescer e invadir a legenda.
            mapa.setAtlasDriven(False)

            # Remove amarrações dinâmicas de escala
            dd_props = mapa.dataDefinedProperties()
            if dd_props.hasProperty(QgsLayoutObject.MapScale):
                prop = dd_props.property(QgsLayoutObject.MapScale)
                prop.setActive(False)
                mapa.setDataDefinedProperties(dd_props)

            # Aplica a extensão visual garantindo que o quadro físico seja preservado
            mapa.zoomToExtent(extent_atual)
            mapa.refresh()

        label_obs = layout.itemById("OBSERVAÇÕES:")
        if label_obs:
            texto = self.dock.mTextEditObs.toPlainText()
            if texto.strip():
                label_obs.setText(f"{texto}")
            else:
                label_obs.setText("")

        layout.refresh()

        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.PdfExportSettings()
        settings.rasterizeWholeLayout = False 
        
        resultado = exporter.exportToPdf(caminho_pdf, settings)

        if resultado == QgsLayoutExporter.Success:
            QMessageBox.information(self.dock, "Sucesso", f"PDF gerado com sucesso!")
            
            # --- ABRE O ARQUIVO AUTOMATICAMENTE APÓS SALVAR ---
            QDesktopServices.openUrl(QUrl.fromLocalFile(caminho_pdf))
        else:
            QMessageBox.warning(self.dock, "Erro", "Ocorreu um erro ao exportar o PDF.")