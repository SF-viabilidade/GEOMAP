import os
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QDockWidget, QMessageBox, QAction, QFileDialog
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import (QgsProject, QgsPrintLayout, QgsReadWriteContext, 
                       QgsGeometry, QgsLayoutExporter, QgsLayoutObject)
from qgis.gui import QgsMapToolExtent, QgsMapCanvas

# Carrega a interface (.ui)
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'gerador_croqui_dialog_base.ui'))

class GeradorCroquiDock(QDockWidget, FORM_CLASS):
    def __init__(self, parent=None):
        super(GeradorCroquiDock, self).__init__(parent)
        self.setupUi(self)

class GeradorCroquiPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.geometria_referencia = None
        self.action = None
        self.dock = None
        self.preview_canvas = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "Gerador de Croqui Valinhos", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Valinhos", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Valinhos", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dock:
            self.iface.removeDockWidget(self.dock)

    def ativar_ferramenta_desenho(self):
        self.tool = QgsMapToolExtent(self.canvas)
        def definir_geometria(extent):
            self.geometria_referencia = QgsGeometry.fromRect(extent)
            self.iface.mapCanvas().unsetMapTool(self.tool)
            self.atualizar_preview()
            
        self.tool.extentChanged.connect(definir_geometria)
        self.iface.mapCanvas().setMapTool(self.tool)

    def atualizar_preview(self):
        """Calcula a área e atualiza o Canvas de pré-visualização no Dock"""
        if not self.geometria_referencia or not self.preview_canvas:
            return

        rect = self.geometria_referencia.boundingBox()
        if rect.width() == 0 and rect.height() == 0:
            rect.grow(10.0)

        # Calcula a margem (%)
        margem_fator = 1.0 + (self.dock.mSpinBoxMargem.value() / 100.0)
        rect.scale(margem_fator)

        # Sincroniza as camadas que estão visíveis no QGIS
        self.preview_canvas.setLayers(self.canvas.layers())
        self.preview_canvas.setExtent(rect)
        self.preview_canvas.refresh()

    def run(self):
        if not self.dock:
            self.dock = GeradorCroquiDock(self.iface.mainWindow())
            
            # --- Configuração CORRIGIDA do Mini Mapa de Preview ---
            self.preview_canvas = QgsMapCanvas(self.dock)
            self.preview_canvas.setCanvasColor(QColor("white"))
            self.preview_canvas.enableAntiAliasing(True)
            self.preview_canvas.setMinimumHeight(180) # Tamanho mais compacto
            
            # Força o mini-mapa a usar o mesmo sistema de coordenadas (CRS) do mapa principal
            self.preview_canvas.setDestinationCrs(self.canvas.mapSettings().destinationCrs())
            self.preview_canvas.setProject(QgsProject.instance())
            
            self.dock.verticalLayoutPreview.addWidget(self.preview_canvas)
            
            # Conexões
            self.dock.btnDesenharRef.clicked.connect(self.ativar_ferramenta_desenho)
            self.dock.btnGerar.clicked.connect(self.processar_layout)
            self.dock.mSpinBoxMargem.valueChanged.connect(self.atualizar_preview)
            
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        
        self.geometria_referencia = None 
        if self.preview_canvas:
            self.preview_canvas.setLayers([])
            self.preview_canvas.refresh()
            
        self.dock.show()

    def processar_layout(self):
        geom = self.geometria_referencia
        
        if not geom:
            QMessageBox.warning(self.dock, "Atenção", "Por favor, clique em 'Definir Centro no Mapa' e desenhe a área antes de gerar.")
            return

        nome_arquivo_sugerido = "Croqui_Situacao.pdf"
        caminho_pdf, _ = QFileDialog.getSaveFileName(
            self.dock, "Salvar Croqui em PDF", nome_arquivo_sugerido, "PDF files (*.pdf)"
        )

        if not caminho_pdf:
            return

        project = QgsProject.instance()
        layout = QgsPrintLayout(project)
        path_qpt = os.path.join(os.path.dirname(__file__), 'croqui_situacao.qpt')
        
        try:
            with open(path_qpt, 'rt', encoding='utf-8') as f:
                xml = f.read()
        except Exception as e:
            QMessageBox.critical(self.dock, "Erro", f"Não foi possível ler o template: {str(e)}")
            return
        
        doc = QDomDocument()
        doc.setContent(xml)
        layout.loadFromTemplate(doc, QgsReadWriteContext())

        total_layouts = len(project.layoutManager().printLayouts())
        layout.setName(f"Croqui_{total_layouts + 1}")
        project.layoutManager().addLayout(layout)

        if layout.atlas().enabled():
            layout.atlas().setEnabled(False)

        mapa = layout.itemById("Mapa 1")
        if mapa:
            mapa.setKeepLayerSet(False)
            mapa.setLayers(self.canvas.mapSettings().layers())

            dd_props = mapa.dataDefinedProperties()
            if dd_props.hasProperty(QgsLayoutObject.MapScale):
                prop = dd_props.property(QgsLayoutObject.MapScale)
                prop.setActive(False)
                mapa.setDataDefinedProperties(dd_props)

            rect = geom.boundingBox()
            if rect.width() == 0 and rect.height() == 0:
                rect.grow(10.0)

            margem_fator = 1.0 + (self.dock.mSpinBoxMargem.value() / 100.0)
            rect.scale(margem_fator)

            mapa.zoomToExtent(rect)
            mapa.refresh()

        label_obs = layout.itemById("OBSERVAÇÕES:")
        if label_obs:
            texto = self.dock.mTextEditObs.toPlainText()
            if texto.strip():
                label_obs.setText(f"{texto}")
            else:
                label_obs.setText("")

        layout.refresh()

        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.PdfExportSettings()
        settings.rasterizeWholeLayout = False 
        
        resultado = exporter.exportToPdf(caminho_pdf, settings)

        if resultado == QgsLayoutExporter.Success:
            QMessageBox.information(self.dock, "Sucesso", f"PDF gerado com sucesso!")
        else:
            QMessageBox.warning(self.dock, "Erro", "Ocorreu um erro ao exportar o PDF.")