def classFactory(iface):
    from .gerador_croqui import GeradorCroquiPlugin
    return GeradorCroquiPlugin(iface)