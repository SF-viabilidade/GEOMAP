# -*- coding: utf-8 -*-
import os
import re
from qgis.core import (QgsProject, QgsFeatureRequest, QgsLayoutExporter, 
                       QgsGeometry, QgsReadWriteContext, QgsPrintLayout, 
                       QgsLayoutItemLabel, QgsExpression, QgsExpressionContext,
                       QgsExpressionContextUtils)
from qgis.gui import QgsMapTool
from qgis.utils import iface
from qgis.PyQt import sip
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QComboBox, QPushButton, QTableWidget, 
                             QTableWidgetItem, QMessageBox, QHeaderView, 
                             QAbstractItemView, QCheckBox, QFileDialog, 
                             QDialog, QFormLayout, QScrollArea, QDialogButtonBox, QGroupBox, QAction)
from PyQt5.QtCore import Qt, QUrl, pyqtSignal
from PyQt5.QtGui import QDesktopServices, QCursor, QIcon
from PyQt5.QtXml import QDomDocument

# ============================================================================
# CLASSES AUXILIARES (SEU CÓDIGO ORIGINAL)
# ============================================================================

class FichaRevisaoDialog(QDialog):
    def __init__(self, feature, layout, layer, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Revisão da Ficha Técnica")
        self.resize(600, 850)
        self.layout_principal = QVBoxLayout(self)
        
        lbl_info = QLabel("<b>Revisão de Dados:</b><br>Edite os valores abaixo conforme necessário.")
        self.layout_principal.addWidget(lbl_info)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        self.layout_content = QVBoxLayout(content)
        
        self.item_inputs = {}
        
        self.grupo_cabecalho = QGroupBox("Número Ficha Técnica")
        self.form_cabecalho = QFormLayout(self.grupo_cabecalho)
        self.grupo_solicitante = QGroupBox("Dados do Solicitante")
        self.form_solicitante = QFormLayout(self.grupo_solicitante)
        self.grupo_imovel = QGroupBox("Dados do Imóvel")
        self.form_imovel = QFormLayout(self.grupo_imovel)
        self.grupo_outros = QGroupBox("Croqui do Imóvel")
        self.form_outros = QFormLayout(self.grupo_outros)

        context = QgsExpressionContext()
        context.appendScope(QgsExpressionContextUtils.globalScope())
        context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
        context.appendScope(QgsExpressionContextUtils.layerScope(layer))
        context.setFeature(feature)

        itens = [i for i in layout.items() if isinstance(i, QgsLayoutItemLabel)]
        itens.sort(key=lambda i: (i.pos().y(), i.pos().x()))

        for item in itens:
            texto_original = item.text()
            pos_y = item.pos().y()
            
            eh_expressao = "[%" in texto_original
            eh_manual = any(x in texto_original for x in ["Nº.", "Requerente", "e-mail", "Telefone", "guia", "processo", "CPF/CNPJ", "Projetos Existentes", "Restrições Urbanisticas"])
            eh_titulo = texto_original.strip() in ["PREFEITURA MUNICIPAL DE VALINHOS", "SECRETARIA DE DESENVOLVIMENTO URBANO", "FICHA TÉCNICA DE IMÓVEL", "Dados do Solicitante", "Dados do Imóvel", "Croqui de imóvel", "Croqui de quadra", "Habite-se:"]
            eh_ignorado = any(x in texto_original for x in ["Data de emissão", "Usuário de emissão"])
            
            if (eh_expressao or eh_manual) and not eh_titulo and not eh_ignorado:
                label_form = ""
                valor_exibicao = texto_original
                prefixo_para_salvar = "" 
                sufixo_para_salvar = ""

                if "Nº." in texto_original and pos_y < 40:
                    label_form = "Numero Ficha:"
                    prefixo_para_salvar = "Nº. "
                    valor_exibicao = texto_original.replace("Nº.", "").strip()
                elif ":" in texto_original:
                    partes = texto_original.split(":", 1) 
                    label_form = partes[0].strip() + ":" 
                    prefixo_para_salvar = partes[0].strip() + ": " 
                    conteudo_bruto = partes[1].strip() if len(partes) > 1 else "" 
                    if "[%" in conteudo_bruto:
                        matches = re.findall(r'\[%(.*?)%\]', conteudo_bruto)
                        valor_resolvido = conteudo_bruto
                        for expr in matches:
                            try:
                                res = QgsExpression(expr).evaluate(context)
                                if res is None: res = ""
                                valor_resolvido = valor_resolvido.replace(f'[%{expr}%]', str(res)).replace(f'[% {expr} %]', str(res))
                            except: pass
                        valor_exibicao = valor_resolvido
                    else:
                        valor_exibicao = conteudo_bruto
                else:
                    label_form = "Campo:"
                    prefixo_para_salvar = ""
                    if "[%" in texto_original:
                        matches = re.findall(r'\[%(.*?)%\]', texto_original)
                        valor_resolvido = texto_original
                        for expr in matches:
                            try:
                                res = QgsExpression(expr).evaluate(context)
                                if res is None: res = ""
                                if label_form == "Campo:": label_form = expr.replace('"', '').replace('_', ' ').title() + ":"
                                valor_resolvido = valor_resolvido.replace(f'[%{expr}%]', str(res)).replace(f'[% {expr} %]', str(res))
                            except: pass
                        valor_exibicao = valor_resolvido
                    else:
                        valor_exibicao = texto_original

                input_field = QLineEdit(str(valor_exibicao))
                self.item_inputs[item] = {"widget": input_field, "prefixo": prefixo_para_salvar, "sufixo": sufixo_para_salvar}
                
                if pos_y < 40: self.form_cabecalho.addRow(label_form, input_field)
                elif 40 <= pos_y < 75: self.form_solicitante.addRow(label_form, input_field)
                elif 75 <= pos_y < 230: self.form_imovel.addRow(label_form, input_field)
                else: self.form_outros.addRow(label_form, input_field)

        if self.form_cabecalho.rowCount() > 0: self.layout_content.addWidget(self.grupo_cabecalho)
        if self.form_solicitante.rowCount() > 0: self.layout_content.addWidget(self.grupo_solicitante)
        if self.form_imovel.rowCount() > 0: self.layout_content.addWidget(self.grupo_imovel)
        if self.form_outros.rowCount() > 0: self.layout_content.addWidget(self.grupo_outros)

        scroll.setWidget(content)
        self.layout_principal.addWidget(scroll)
        botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botoes.accepted.connect(self.accept)
        botoes.rejected.connect(self.reject)
        self.layout_principal.addWidget(botoes)

    def aplicar_alteracoes_no_layout(self):
        for item, dados in self.item_inputs.items():
            texto_final = f"{dados['prefixo']}{dados['widget'].text()}"
            item.setText(texto_final)

class ToolSelecionarFicha(QgsMapTool):
    imovel_encontrado = pyqtSignal(object)

    def __init__(self, canvas, layer):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.setCursor(QCursor(Qt.CrossCursor))

    def canvasReleaseEvent(self, event):
        point_xy = self.toMapCoordinates(event.pos())
        point_geom = QgsGeometry.fromPointXY(point_xy)
        radius = self.canvas.mapUnitsPerPixel() * 3
        rect = point_geom.buffer(radius, 5).boundingBox()
        request = QgsFeatureRequest().setFilterRect(rect)
        candidatos = list(self.layer.getFeatures(request))
        feature_selecionada = None
        for feat in candidatos:
            if feat.geometry().contains(point_geom):
                feature_selecionada = feat
                break 
        if not feature_selecionada and candidatos:
            candidatos.sort(key=lambda f: f.geometry().distance(point_geom))
            feature_selecionada = candidatos[0]
        
        if feature_selecionada:
            self.imovel_encontrado.emit(feature_selecionada)
        else:
            iface.messageBar().pushMessage("Ficha", "Nenhum imóvel encontrado.", level=1, duration=2)

class FichaTecnicaDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("Gerador de Ficha Técnica", parent)
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.widget_principal = QWidget()
        self.layout = QVBoxLayout()
        self.widget_principal.setLayout(self.layout)
        self.tool_selecao = None
        
        # Define caminho do QPT relativo à pasta do plugin
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.caminho_qpt = os.path.join(current_dir, "FICHA_TECNICA.qpt")
        
        # UI
        self.lbl_titulo = QLabel("<b>GERADOR DE FICHA TÉCNICA</b>")
        self.lbl_titulo.setAlignment(Qt.AlignCenter)
        self.combo_tipo = QComboBox()
        self.combo_tipo.addItems(["Inscrição Imobiliária", "Proprietário", "CPF ou CNPJ", "Endereço"])
        self.input_termo = QLineEdit()
        self.input_termo.setPlaceholderText("Buscar...")
        self.input_termo.returnPressed.connect(self.realizar_busca)
        self.chk_exata = QCheckBox("Busca Exata")
        
        layout_botoes = QHBoxLayout()
        self.btn_buscar = QPushButton("🔍 Buscar")
        self.btn_buscar.clicked.connect(self.realizar_busca)
        self.btn_mapa = QPushButton("🖱️ Selecionar no Mapa")
        self.btn_mapa.setStyleSheet("background-color: #FF9800; color: white; font-weight: bold;")
        self.btn_mapa.clicked.connect(self.ativar_ferramenta_mapa)
        layout_botoes.addWidget(self.btn_buscar)
        layout_botoes.addWidget(self.btn_mapa)
        
        self.tabela = QTableWidget()
        self.tabela.setColumnCount(3)
        self.tabela.setHorizontalHeaderLabels(["Inscrição", "Proprietário", "Endereço"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.itemClicked.connect(self.navegar_para_imovel)
        self.tabela.itemDoubleClicked.connect(self.iniciar_processo_ficha)
        
        self.lbl_info = QLabel("<i>* Clique para localizar. Duplo clique para gerar.</i>")
        self.lbl_info.setStyleSheet("color: gray; font-size: 10px;")

        self.layout.addWidget(self.lbl_titulo)
        self.layout.addWidget(self.combo_tipo)
        self.layout.addWidget(self.input_termo)
        self.layout.addWidget(self.chk_exata)
        self.layout.addLayout(layout_botoes)
        self.layout.addWidget(self.tabela)
        self.layout.addWidget(self.lbl_info)
        self.setWidget(self.widget_principal)

    def get_layer(self):
        layers = QgsProject.instance().mapLayersByName('IMOBILIARIO')
        if not layers:
            QMessageBox.warning(self, "Erro", "Camada 'IMOBILIARIO' não encontrada.")
            return None
        return layers[0]

    def realizar_busca(self):
        layer = self.get_layer()
        if not layer: return
        termo = self.input_termo.text().strip()
        if not termo: return
        tipo = self.combo_tipo.currentText()
        exata = self.chk_exata.isChecked()
        sql = ""
        if tipo == "Inscrição Imobiliária":
            if exata: sql = f"\"inscricao\" = '{termo}' OR \"BD_SMAR_Inscrição Físico\" = '{termo}'"
            else: sql = f"\"inscricao\" LIKE '%{termo}%' OR \"BD_SMAR_Inscrição Físico\" LIKE '%{termo}%'"
        elif tipo == "Proprietário":
            op = "ILIKE"
            fmt = f"'{termo}'" if exata else f"'%{termo}%'"
            sql = f"\"BD_SMAR_Proprietário\" {op} {fmt}"
        elif tipo == "CPF ou CNPJ":
            nums = re.sub(r'[^0-9]', '', termo)
            if not nums: return
            sql = f"\"BD_SMAR_CNPJ/CPF Proprietário\" LIKE '%{nums}%'"
        elif tipo == "Endereço":
            sql = f"\"BD_SMAR_Imóvel Endereço\" ILIKE '%{termo}%'"

        try:
            req = QgsFeatureRequest().setFilterExpression(sql)
            feats = list(layer.getFeatures(req))
        except Exception as e:
            iface.messageBar().pushMessage("Erro SQL", str(e), level=2)
            return
        
        self.tabela.setRowCount(0)
        self.tabela.setSortingEnabled(False)
        for feat in feats:
            row = self.tabela.rowCount()
            self.tabela.insertRow(row)
            self.tabela.setItem(row, 0, QTableWidgetItem(str(feat["inscricao"] or "")))
            self.tabela.setItem(row, 1, QTableWidgetItem(str(feat["BD_SMAR_Proprietário"] or "")))
            self.tabela.setItem(row, 2, QTableWidgetItem(str(feat["BD_SMAR_Imóvel Endereço"] or "")))
            self.tabela.item(row, 0).setData(Qt.UserRole, feat.id())
        self.tabela.setSortingEnabled(True)

    def navegar_para_imovel(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        layer.removeSelection()
        layer.selectByIds([fid])
        box = layer.boundingBoxOfSelected()
        if box.width() == 0 and box.height() == 0:
             scale = iface.mapCanvas().mapUnitsPerPixel()
             box.grow(scale * 100)
        else:
             box.scale(1.1)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

    def ativar_ferramenta_mapa(self):
        layer = self.get_layer()
        if not layer: return
        self.tool_selecao = ToolSelecionarFicha(iface.mapCanvas(), layer)
        self.tool_selecao.imovel_encontrado.connect(self.iniciar_processo_ficha_mapa)
        iface.mapCanvas().setMapTool(self.tool_selecao)
        iface.messageBar().pushMessage("Ativo", "Clique no imóvel no mapa.", level=0, duration=3)

    def iniciar_processo_ficha(self, item):
        layer = self.get_layer()
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        feat = layer.getFeature(fid)
        self.preparar_layout_e_revisar(feat, layer)

    def iniciar_processo_ficha_mapa(self, feat):
        layer = self.get_layer()
        self.preparar_layout_e_revisar(feat, layer)

    def preparar_layout_e_revisar(self, feature, layer):
        if not os.path.exists(self.caminho_qpt):
            QMessageBox.critical(self, "Erro", f"Arquivo .qpt não encontrado em:\n{self.caminho_qpt}")
            return

        layer.removeSelection()
        layer.selectByIds([feature.id()])
        iface.mapCanvas().zoomToSelected()
        
        project = QgsProject.instance()
        manager = project.layoutManager()
        layout_name = "A4 - Ficha Técnica (Revisão)"
        
        layout = manager.layoutByName(layout_name)
        if layout:
            if sip.isdeleted(layout):
                layout = QgsPrintLayout(project)
                layout.setName(layout_name)
                manager.addLayout(layout)
            else:
                layout.initializeDefaults()
        else:
            layout = QgsPrintLayout(project)
            layout.setName(layout_name)
            manager.addLayout(layout)

        try:
            with open(self.caminho_qpt, 'r', encoding='utf-8') as f:
                content = f.read()
            doc = QDomDocument()
            doc.setContent(content)
            layout.readXml(doc.documentElement(), doc, QgsReadWriteContext())
            
            dialog = FichaRevisaoDialog(feature, layout, layer, iface.mainWindow())
            
            if dialog.exec_() == QDialog.Accepted:
                dialog.aplicar_alteracoes_no_layout()
                self.gerar_pdf_final(layout, feature, layer)
        except Exception as e:
            QMessageBox.critical(self, "Erro Fatal", f"Falha ao processar: {str(e)}")

    def gerar_pdf_final(self, layout, feature, layer):
        try:
            atlas = layout.atlas()
            atlas.setCoverageLayer(layer)
            atlas.setEnabled(True)
            atlas.setFilterExpression(f"$id = {feature.id()}") 
            
            inscricao = feature["inscricao"] if feature["inscricao"] else "sem_inscricao"
            safe_name = re.sub(r'[\\/*?:"<>|]', "", str(inscricao))
            padrao = os.path.join(os.path.expanduser("~"), f"Ficha_{safe_name}.pdf")
            
            caminho, _ = QFileDialog.getSaveFileName(self, "Salvar PDF", padrao, "PDF Files (*.pdf)")
            
            if caminho:
                atlas.beginRender()
                atlas.seekTo(feature)
                exporter = QgsLayoutExporter(layout)
                settings = QgsLayoutExporter.PdfExportSettings()
                result = exporter.exportToPdf(caminho, settings)
                atlas.endRender()
                
                if result == QgsLayoutExporter.Success:
                    iface.messageBar().pushMessage("Sucesso", f"Salvo: {caminho}", level=0, duration=3)
                    QDesktopServices.openUrl(QUrl.fromLocalFile(caminho))
                else:
                    QMessageBox.warning(self, "Atenção", "Erro ao exportar.")
        except Exception as e:
            QMessageBox.critical(self, "Erro na Geração", str(e))
# ... (Mantenha todo o código anterior até chegar na classe FichaTecnicaPlugin) ...

# ============================================================================
# CLASSE PRINCIPAL DO PLUGIN (ATUALIZADA COM ÍCONE)
# ============================================================================

class FichaTecnicaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None
        # Caminho para a pasta onde o plugin está instalado
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        # Caminho completo para o ícone
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        
        # Cria a ação COM O ÍCONE
        self.action = QAction(QIcon(icon_path), "Gerar Ficha Técnica", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # Adiciona ao menu de plugins e à barra de ferramentas
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Gerador Ficha Técnica", self.action)

    def unload(self):
        # Remove UI
        if self.dock:
            self.iface.removeDockWidget(self.dock)
            self.dock.close()
        
        self.iface.removePluginMenu("Gerador Ficha Técnica", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not self.dock:
            self.dock = FichaTecnicaDock(self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        
        self.dock.show()
        self.dock.raise_()