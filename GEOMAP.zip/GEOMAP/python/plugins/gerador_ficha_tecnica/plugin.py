# -*- coding: utf-8 -*-
import os
import re
from qgis.core import (QgsProject, QgsFeatureRequest, QgsLayoutExporter, 
                       QgsGeometry, QgsReadWriteContext, QgsPrintLayout, 
                       QgsLayoutItemLabel, QgsExpression, QgsExpressionContext,
                       QgsExpressionContextUtils, QgsVectorLayer)
from qgis.gui import QgsMapTool
from qgis.utils import iface
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QComboBox, QPushButton, QTableWidget, 
                             QTableWidgetItem, QMessageBox, QHeaderView, 
                             QAbstractItemView, QCheckBox, QFileDialog, 
                             QDialog, QFormLayout, QScrollArea, QDialogButtonBox, 
                             QGroupBox, QAction)
from PyQt5.QtCore import Qt, QUrl, pyqtSignal, QCoreApplication
from PyQt5.QtGui import QDesktopServices, QCursor, QIcon
from PyQt5.QtXml import QDomDocument

# ============================================================================
# CONFIGURAÇÕES GERAIS
# ============================================================================
NOME_CAMADA_MAPA = 'IMOBILIARIO'
NOME_TABELA_DADOS = 'CIVIDAS 29-10-25'
CAMPO_CHAVE_MAPA = 'inscricao'        # Chave na camada espacial (IMOBILIARIO)
CAMPO_CHAVE_TABELA = 'Ins. Municipal' # Chave na tabela de dados (CIVIDAS)
NOME_LAYOUT_TEMP = "__FICHA_GERADOR_TEMP__"

# ============================================================================
# 1. JANELA DE REVISÃO
# ============================================================================
class FichaRevisaoDialog(QDialog):
    def __init__(self, feature, layout, layer, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Revisão da Ficha Técnica")
        self.resize(600, 850)
        
        self.layout_principal = QVBoxLayout(self)
        
        lbl_info = QLabel(
            "<b>Revisão de Dados:</b><br>"
            "Os campos editados serão salvos na tabela <i>CIVIDAS</i> (se vinculados) e o mapa será atualizado."
        )
        self.layout_principal.addWidget(lbl_info)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        self.layout_content = QVBoxLayout(content)
        
        self.item_inputs = {}      
        self.mapeamento_banco = {} 
        
        # Criação dos Grupos
        self.grupo_cabecalho = QGroupBox("Cabeçalho")
        self.form_cabecalho = QFormLayout(self.grupo_cabecalho)
        
        self.grupo_solicitante = QGroupBox("Solicitante")
        self.form_solicitante = QFormLayout(self.grupo_solicitante)
        
        self.grupo_imovel = QGroupBox("Dados do Imóvel")
        self.form_imovel = QFormLayout(self.grupo_imovel)
        
        self.grupo_outros = QGroupBox("Outros / Banco de Dados")
        self.form_outros = QFormLayout(self.grupo_outros)

        context = QgsExpressionContext()
        context.appendScope(QgsExpressionContextUtils.globalScope())
        context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
        context.appendScope(QgsExpressionContextUtils.layerScope(layer))
        context.setFeature(feature)

        itens = [i for i in layout.items() if isinstance(i, QgsLayoutItemLabel)]
        # Ordena itens pela posição Y e depois X
        itens.sort(key=lambda i: (i.pos().y(), i.pos().x()))

        for item in itens:
            texto_original = item.text()
            pos_y = item.pos().y()
            
            eh_expressao = "[%" in texto_original
            
            # --- LISTA DE CAMPOS DETECTADOS MANUALMENTE (Atualizada) ---
            eh_manual = any(x in texto_original for x in [
                "Projetos Existentes", "Restrições Urbanisticas", "Habite-se", 
                "Nº.", "Requerente", "e-mail", "Telefone", "CPF/CNPJ",
                "Data do pedido", "Finalidade", "Uso Pretendido",
                "Viela Sanitária", "Viela Sanitaria", "Area Edificada", "Área Edificada"
            ])
            # -----------------------------------------------------------
            
            ignorar = ["PREFEITURA", "SECRETARIA", "FICHA TÉCNICA", "Croqui", "Dados"]
            if any(ig in texto_original for ig in ignorar): continue

            if eh_expressao or eh_manual:
                label_form = "Campo:"
                valor_exibicao = texto_original
                prefixo = "" 
                sufixo = ""

                # Lógica de Extração e Limpeza
                if ":" in texto_original:
                    partes = texto_original.split(":", 1)
                    label_form = partes[0].strip() + ":"
                    prefixo = partes[0].strip() + ": "
                    conteudo = partes[1].strip() if len(partes) > 1 else ""
                    
                    if "[%" in conteudo:
                        matches = re.findall(r'\[%(.*?)%\]', conteudo)
                        valor_resolvido = conteudo
                        for expr in matches:
                            try:
                                res = QgsExpression(expr).evaluate(context)
                                if res is None or res == 'NULL': res = ""
                                valor_resolvido = valor_resolvido.replace(f'[%{expr}%]', str(res)).replace(f'[% {expr} %]', str(res))
                            except: pass
                        valor_exibicao = valor_resolvido
                    else: valor_exibicao = conteudo
                
                elif "Nº." in texto_original and pos_y < 40:
                    label_form = "Ficha Nº:"
                    prefixo = "Nº. "
                    valor_exibicao = texto_original.replace("Nº.", "").strip()

                elif "[%" in texto_original:
                    matches = re.findall(r'\[%(.*?)%\]', texto_original)
                    valor_resolvido = texto_original
                    for expr in matches:
                        try:
                            res = QgsExpression(expr).evaluate(context)
                            if res is None or res == 'NULL': res = ""
                            valor_resolvido = valor_resolvido.replace(f'[%{expr}%]', str(res)).replace(f'[% {expr} %]', str(res))
                        except: pass
                    valor_exibicao = valor_resolvido

                # --- SUBSTITUIÇÃO: Área Edificada -> Viela Sanitária ---
                if "Area Edificada" in texto_original or "Área Edificada" in texto_original:
                    label_form = "Viela Sanitária:"
                # -------------------------------------------------------

                # Limpeza final de NULL string
                if valor_exibicao.strip() in ['NULL', 'None']:
                    valor_exibicao = ""

                input_field = QLineEdit(str(valor_exibicao))
                self.item_inputs[item] = {"widget": input_field, "prefixo": prefixo, "sufixo": sufixo}
                
                # Mapeamento para Tabela CIVIDAS
                if "Habite-se" in texto_original:
                    self.mapeamento_banco["HABITE-SE N°"] = input_field
                elif "Projetos Existentes" in texto_original:
                    self.mapeamento_banco["Projetos Existentes"] = input_field
                elif "Restrições Urbanisticas" in texto_original or "Restrições Urbanísticas" in texto_original:
                    self.mapeamento_banco["Restricoes Urbanisticas"] = input_field

                # --- LÓGICA DE AGRUPAMENTO DE CAMPOS ---
                if "Data do pedido" in texto_original:
                    self.form_cabecalho.addRow(label_form, input_field)
                elif "Finalidade" in texto_original or "Uso Pretendido" in texto_original:
                    self.form_imovel.addRow(label_form, input_field)
                # Verifica se é Viela Sanitária (por nome original ou label alterado)
                elif "Viela Sanitária" in label_form or "Viela Sanitaria" in texto_original:
                    self.form_imovel.addRow(label_form, input_field)
                
                # Lógica padrão baseada na posição Y
                elif pos_y < 40: 
                    self.form_cabecalho.addRow(label_form, input_field)
                elif 40 <= pos_y < 75: 
                    self.form_solicitante.addRow(label_form, input_field)
                elif 75 <= pos_y < 230: 
                    self.form_imovel.addRow(label_form, input_field)
                else: 
                    self.form_outros.addRow(label_form, input_field)
                # ---------------------------------------

        # Adiciona os grupos ao layout se tiverem campos
        if self.form_cabecalho.rowCount() > 0: self.layout_content.addWidget(self.grupo_cabecalho)
        if self.form_solicitante.rowCount() > 0: self.layout_content.addWidget(self.grupo_solicitante)
        if self.form_imovel.rowCount() > 0: self.layout_content.addWidget(self.grupo_imovel)
        if self.form_outros.rowCount() > 0: self.layout_content.addWidget(self.grupo_outros)

        scroll.setWidget(content)
        self.layout_principal.addWidget(scroll)
        
        botoes = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        botoes.accepted.connect(self.accept)
        botoes.rejected.connect(self.reject)
        self.layout_principal.addWidget(botoes)

    def aplicar_alteracoes_no_layout(self):
        for item, dados in self.item_inputs.items():
            item.setText(f"{dados['prefixo']}{dados['widget'].text()}{dados['sufixo']}")

    def obter_dados_para_salvar(self):
        dados = {}
        for coluna, widget in self.mapeamento_banco.items():
            dados[coluna] = widget.text()
        return dados

# ============================================================================
# 2. FERRAMENTA DE MAPA
# ============================================================================
class ToolSelecionarFicha(QgsMapTool):
    imovel_encontrado = pyqtSignal(object)
    def __init__(self, canvas, layer):
        super().__init__(canvas)
        self.layer = layer
        self.setCursor(QCursor(Qt.CrossCursor))
    def canvasReleaseEvent(self, event):
        point = QgsGeometry.fromPointXY(self.toMapCoordinates(event.pos()))
        radius = self.canvas().mapUnitsPerPixel() * 3
        req = QgsFeatureRequest().setFilterRect(point.buffer(radius, 5).boundingBox())
        candidatos = list(self.layer.getFeatures(req))
        feat = next((f for f in candidatos if f.geometry().contains(point)), None)
        if not feat and candidatos: feat = candidatos[0]
        if feat: self.imovel_encontrado.emit(feat)
        else: iface.messageBar().pushMessage("Ficha", "Nenhum imóvel encontrado.", level=1, duration=2)

# ============================================================================
# 3. DOCK PRINCIPAL
# ============================================================================
class FichaTecnicaDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("Gerador de Ficha Técnica", parent)
        self.setAllowedAreas(Qt.RightDockWidgetArea | Qt.LeftDockWidgetArea)
        self.widget_principal = QWidget()
        self.layout = QVBoxLayout()
        self.widget_principal.setLayout(self.layout)
        self.tool_selecao = None
        self.caminho_qpt = os.path.join(os.path.dirname(os.path.abspath(__file__)), "FICHA_TECNICA.qpt")
        
        self.lbl_titulo = QLabel("<b>GERADOR DE FICHA TÉCNICA</b>")
        self.lbl_titulo.setAlignment(Qt.AlignCenter)
        self.combo_tipo = QComboBox()
        self.combo_tipo.addItems(["Inscrição Imobiliária", "Proprietário", "CPF ou CNPJ", "Endereço"])
        
        self.input_termo = QLineEdit()
        self.input_termo.returnPressed.connect(self.realizar_busca)
        self.chk_exata = QCheckBox("Busca Exata")
        
        btns = QHBoxLayout()
        self.btn_buscar = QPushButton("🔍 Buscar")
        self.btn_buscar.clicked.connect(self.realizar_busca)
        self.btn_mapa = QPushButton("🖱️ Selecionar no Mapa")
        self.btn_mapa.setStyleSheet("background-color: #FF9800; color: white; font-weight: bold;")
        self.btn_mapa.clicked.connect(self.ativar_ferramenta_mapa)
        btns.addWidget(self.btn_buscar)
        btns.addWidget(self.btn_mapa)
        
        self.tabela = QTableWidget()
        self.tabela.setColumnCount(3)
        self.tabela.setHorizontalHeaderLabels(["Inscrição", "Proprietário", "Endereço"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tabela.horizontalHeader().setStretchLastSection(True)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.itemClicked.connect(self.navegar)
        self.tabela.itemDoubleClicked.connect(self.iniciar)
        
        self.layout.addWidget(self.lbl_titulo)
        self.layout.addWidget(self.combo_tipo)
        self.layout.addWidget(self.input_termo)
        self.layout.addWidget(self.chk_exata)
        self.layout.addLayout(btns)
        self.layout.addWidget(self.tabela)
        self.setWidget(self.widget_principal)

    def get_layer(self):
        layers = QgsProject.instance().mapLayersByName(NOME_CAMADA_MAPA)
        if not layers:
            QMessageBox.warning(self, "Erro", f"Camada '{NOME_CAMADA_MAPA}' não encontrada.")
            return None
        return layers[0]

    def realizar_busca(self):
        layer = self.get_layer()
        if not layer: return
        termo = self.input_termo.text().strip()
        if not termo: return
        idx = self.combo_tipo.currentIndex()
        if idx == 0:
            sql = f"\"inscricao\" = '{termo}'" if self.chk_exata.isChecked() else f"\"inscricao\" LIKE '%{termo}%'"
        elif idx == 1: sql = f"\"BD_SMAR_Proprietário\" ILIKE '%{termo}%'"
        elif idx == 2: sql = f"\"BD_SMAR_CNPJ/CPF Proprietário\" LIKE '%{re.sub(r'[^0-9]', '', termo)}%'"
        elif idx == 3: sql = f"\"BD_SMAR_Imóvel Endereço\" ILIKE '%{termo}%'"

        try:
            req = QgsFeatureRequest().setFilterExpression(sql)
            feats = list(layer.getFeatures(req))
            self.tabela.setRowCount(0)
            self.tabela.setSortingEnabled(False)
            for f in feats:
                r = self.tabela.rowCount()
                self.tabela.insertRow(r)
                self.tabela.setItem(r, 0, QTableWidgetItem(str(f["inscricao"] or "")))
                self.tabela.setItem(r, 1, QTableWidgetItem(str(f["BD_SMAR_Proprietário"] or "")))
                self.tabela.setItem(r, 2, QTableWidgetItem(str(f["BD_SMAR_Imóvel Endereço"] or "")))
                self.tabela.item(r, 0).setData(Qt.UserRole, f.id())
            self.tabela.setSortingEnabled(True)
        except Exception as e: iface.messageBar().pushMessage("Erro Busca", str(e), level=2)

    def navegar(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        layer.selectByIds([fid])
        box = layer.boundingBoxOfSelected()
        box.scale(1.5)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

    def ativar_ferramenta_mapa(self):
        l = self.get_layer()
        if not l: return
        self.tool_selecao = ToolSelecionarFicha(iface.mapCanvas(), l)
        self.tool_selecao.imovel_encontrado.connect(lambda f: self.preparar_layout_e_revisar(f, l))
        iface.mapCanvas().setMapTool(self.tool_selecao)

    def iniciar(self, item):
        l = self.get_layer()
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        self.preparar_layout_e_revisar(l.getFeature(fid), l)

    def preparar_layout_e_revisar(self, feature, layer):
        if not os.path.exists(self.caminho_qpt): return QMessageBox.critical(self, "Erro", "QPT não encontrado.")
        layer.removeSelection()
        layer.selectByIds([feature.id()])
        iface.mapCanvas().zoomToSelected()
        
        project = QgsProject.instance()
        manager = project.layoutManager()
        if l := manager.layoutByName(NOME_LAYOUT_TEMP): manager.removeLayout(l)
        layout = QgsPrintLayout(project)
        layout.setName(NOME_LAYOUT_TEMP)
        manager.addLayout(layout)

        try:
            with open(self.caminho_qpt, 'r', encoding='utf-8') as f: content = f.read()
            doc = QDomDocument()
            doc.setContent(content)
            layout.readXml(doc.documentElement(), doc, QgsReadWriteContext())
            layout.setName(NOME_LAYOUT_TEMP)
            
            dialog = FichaRevisaoDialog(feature, layout, layer, iface.mainWindow())
            if dialog.exec_() == QDialog.Accepted:
                dialog.aplicar_alteracoes_no_layout()
                dados_banco = dialog.obter_dados_para_salvar()
                
                # Salva e força atualização
                self.salvar_na_tabela_externa(feature[CAMPO_CHAVE_MAPA], dados_banco)
                
                self.gerar_pdf(layout, feature, layer)
        except Exception as e: QMessageBox.critical(self, "Erro", str(e))
        finally:
            if l := manager.layoutByName(NOME_LAYOUT_TEMP): manager.removeLayout(l)

    def salvar_na_tabela_externa(self, chave_valor, dados):
        """Atualiza tabela externa e limpa cache do Join."""
        if not dados: return

        tabelas = QgsProject.instance().mapLayersByName(NOME_TABELA_DADOS)
        if not tabelas: return QMessageBox.critical(self, "Erro", f"Tabela '{NOME_TABELA_DADOS}' não encontrada.")
        
        tabela_alvo = tabelas[0]
        expr = f"\"{CAMPO_CHAVE_TABELA}\" = '{chave_valor}'"
        it = tabela_alvo.getFeatures(QgsFeatureRequest().setFilterExpression(expr))
        linhas = list(it)
        
        if not linhas: return QMessageBox.warning(self, "Aviso", f"Registro {chave_valor} não encontrado na tabela.")
        
        feat_tabela = linhas[0]
        campos_alterados = {}
        msg_debug = []
        
        for nome_col, novo_val in dados.items():
            idx = tabela_alvo.fields().indexOf(nome_col)
            if idx == -1: continue
            
            val_atual = feat_tabela[nome_col]
            str_atual = str(val_atual) if val_atual is not None else ""
            str_novo = str(novo_val)
            
            if str_atual != str_novo:
                # Salva como string vazia para limpar campos (não NULL)
                campos_alterados[idx] = novo_val 
                msg_debug.append(f"{nome_col}: {novo_val}")

        if not campos_alterados: return

        msg = f"<b>Alteração em {NOME_TABELA_DADOS}</b><br><br>Chave: {chave_valor}<br>" + "<br>".join(msg_debug) + "<br><br>Confirmar atualização?"
        if QMessageBox.question(self, "Salvar", msg, QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes: return

        try:
            sucesso = tabela_alvo.dataProvider().changeAttributeValues({ feat_tabela.id() : campos_alterados })
            
            if sucesso:
                iface.messageBar().pushMessage("Sucesso", "Dados salvos no banco.", level=0, duration=2)
                
                # Sequência de atualização de cache
                QCoreApplication.processEvents()
                tabela_alvo.reload()
                QCoreApplication.processEvents()
                
                layer_mapa = self.get_layer()
                if layer_mapa:
                    layer_mapa.reload()
                    layer_mapa.triggerRepaint()
                    iface.mapCanvas().refresh()
            else:
                QMessageBox.critical(self, "Erro SQL", f"Erro ao gravar: {tabela_alvo.dataProvider().lastError()}")
        except Exception as e: QMessageBox.critical(self, "Erro", str(e))

    def gerar_pdf(self, layout, feature, layer):
        atlas = layout.atlas()
        atlas.setCoverageLayer(layer)
        atlas.setEnabled(True)
        atlas.setFilterExpression(f"$id = {feature.id()}")
        
        safe = re.sub(r'[\\/*?:"<>|]', "", str(feature["inscricao"] or "sem_inscricao"))
        padrao = os.path.join(os.path.expanduser("~"), f"Ficha_{safe}.pdf")
        
        path, _ = QFileDialog.getSaveFileName(self, "Salvar PDF", padrao, "PDF (*.pdf)")
        if path:
            atlas.beginRender()
            atlas.seekTo(feature)
            exp = QgsLayoutExporter(layout)
            if exp.exportToPdf(path, QgsLayoutExporter.PdfExportSettings()) == 0:
                iface.messageBar().pushMessage("Sucesso", f"Salvo: {path}", level=0, duration=3)
                QDesktopServices.openUrl(QUrl.fromLocalFile(path))
            atlas.endRender()

class FichaTecnicaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None
    def initGui(self):
        icon = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon), "Gerar Ficha Técnica", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Gerador Ficha Técnica", self.action)
    def unload(self):
        if self.dock: self.iface.removeDockWidget(self.dock)
        self.iface.removePluginMenu("Gerador Ficha Técnica", self.action)
        self.iface.removeToolBarIcon(self.action)
        mgr = QgsProject.instance().layoutManager()
        if l := mgr.layoutByName(NOME_LAYOUT_TEMP): mgr.removeLayout(l)
    def run(self):
        if not self.dock:
            self.dock = FichaTecnicaDock(self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.show()
        self.dock.raise_()