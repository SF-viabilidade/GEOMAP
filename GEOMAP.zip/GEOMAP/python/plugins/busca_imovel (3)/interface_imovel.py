# ARQUIVO: interface_imovel.py
import os
import re
import glob
import shutil
import unicodedata
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, 
                             QHeaderView, QAbstractItemView, QDialog, 
                             QFormLayout, QGroupBox, QScrollArea, QTabWidget, 
                             QComboBox, QCheckBox, QFileDialog, QSizePolicy,
                             QListWidget, QListWidgetItem, QMessageBox)
from PyQt5.QtCore import Qt, pyqtSignal, QUrl
from PyQt5.QtGui import QIcon, QPixmap, QDesktopServices, QCursor

from qgis.core import (QgsProject, QgsFeatureRequest, QgsLayoutExporter, 
                       QgsGeometry, QgsVectorLayer, QgsReadWriteContext, 
                       QgsPrintLayout)
from qgis.gui import QgsMapTool
from qgis.utils import iface

# ============================================================================
# FUNÇÕES UTILITÁRIAS
# ============================================================================
def normalize_str(s):
    """Remove acentos e coloca em minúsculas."""
    if not s: return ""
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) 
                   if unicodedata.category(c) != 'Mn').lower()

# ============================================================================
# 1. CLASSE DA FICHA CADASTRAL (COM TODAS AS FUNCIONALIDADES)
# ============================================================================
class FichaImovelDialog(QDialog):
    def __init__(self, feature, layer, parent=None):
        super().__init__(parent)
        self.feature = feature
        self.layer = layer 
        
        self.inscricao = "N/A"
        # Tenta achar a inscrição varrendo colunas
        for field in layer.fields():
            name_norm = normalize_str(field.name())
            if 'inscricao' in name_norm or name_norm == 'im':
                val = feature[field.name()]
                if val: self.inscricao = str(val)
                break
        
        # Limpa inscrição para uso em caminhos de arquivo e consultas
        self.inscricao_limpa = re.sub(r'[^0-9]', '', self.inscricao)

        self.setWindowTitle(f"Ficha: {self.inscricao}")
        self.setMinimumWidth(950)
        self.setMinimumHeight(700)

        layout_principal = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout_principal.addWidget(self.tabs)

        # Abas
        self.tab_dados = QWidget()
        self.setup_aba_dados(self.tab_dados)
        self.tabs.addTab(self.tab_dados, "Dados Gerais")

        self.tab_fotos = QWidget()
        self.setup_aba_fotos(self.tab_fotos)
        self.tabs.addTab(self.tab_fotos, "Fachada")

        self.tab_anexos = QWidget()
        self.setup_aba_anexos(self.tab_anexos)
        self.tabs.addTab(self.tab_anexos, "Anexos")

        self.tab_historico = QWidget()
        self.setup_aba_historico(self.tab_historico)
        self.tabs.addTab(self.tab_historico, "Histórico")

        # Botões Rodapé
        hbox_btns = QHBoxLayout()
        self.btn_croqui = QPushButton("Gerar Croqui (PDF)")
        self.btn_croqui.setStyleSheet("font-weight: bold; padding: 6px; background-color: #e0e0e0;")
        self.btn_croqui.clicked.connect(self.gerar_croqui_local)
        hbox_btns.addWidget(self.btn_croqui)
        
        hbox_btns.addStretch()
        
        btn_fechar = QPushButton("Fechar")
        btn_fechar.clicked.connect(self.accept)
        hbox_btns.addWidget(btn_fechar)

        layout_principal.addLayout(hbox_btns)

    # --- ABA DADOS ---
    def setup_aba_dados(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        
        table = QTableWidget()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Campo", "Valor"])
        table.setAlternatingRowColors(True)
        table.setStyleSheet("QTableWidget { alternate-background-color: #f5f5f5; background-color: #ffffff; }")
        
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)

        fields = self.layer.fields()
        table.setRowCount(len(fields))
        
        for i, field in enumerate(fields):
            nome_campo = field.name()
            try:
                val = self.feature[nome_campo]
            except KeyError:
                val = ""
            
            valor_str = str(val) if val is not None else ""
            
            item_key = QTableWidgetItem(nome_campo)
            item_key.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            font = item_key.font()
            font.setBold(True)
            item_key.setFont(font)
            
            item_val = QTableWidgetItem(valor_str)
            item_val.setToolTip(valor_str) 
            
            table.setItem(i, 0, item_key)
            table.setItem(i, 1, item_val)

        layout.addWidget(table)

    # --- ABA FOTOS ---
    def setup_aba_fotos(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        
        self.lbl_imagem = QLabel("Carregando...")
        self.lbl_imagem.setAlignment(Qt.AlignCenter)
        self.lbl_imagem.setStyleSheet("background-color: #333; color: white; font-weight: bold;")
        self.lbl_imagem.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.lbl_imagem.setMinimumHeight(400)
        layout.addWidget(self.lbl_imagem)

        hbox_nav = QHBoxLayout()
        self.btn_prev = QPushButton("<< Anterior")
        self.btn_prev.clicked.connect(self.foto_anterior)
        self.btn_next = QPushButton("Próxima >>")
        self.btn_next.clicked.connect(self.foto_proxima)
        self.lbl_contador = QLabel("0/0")
        self.lbl_contador.setAlignment(Qt.AlignCenter)

        hbox_nav.addWidget(self.btn_prev)
        hbox_nav.addWidget(self.lbl_contador)
        hbox_nav.addWidget(self.btn_next)
        layout.addLayout(hbox_nav)

        self.lista_fotos = []
        self.indice_atual = 0
        
        base_path = r"P:\Ortofotos 2023\05. Foto-Fachada para Entrega"
        
        if not os.path.exists(base_path):
            self.lbl_imagem.setText(f"Diretório não encontrado (P:).")
            self.btn_prev.setEnabled(False)
            self.btn_next.setEnabled(False)
            return

        if self.inscricao_limpa:
            padroes = [
                os.path.join(base_path, f"{self.inscricao_limpa}.*"),
                os.path.join(base_path, f"{self.inscricao_limpa}_*.*")
            ]
            encontrados = []
            for p in padroes: encontrados.extend(glob.glob(p))
            exts = ['.jpg', '.jpeg', '.png', '.bmp']
            self.lista_fotos = sorted(list(set([f for f in encontrados if os.path.splitext(f)[1].lower() in exts])))

        if self.lista_fotos:
            self.carregar_imagem(0)
        else:
            self.lbl_imagem.setText("Nenhuma foto encontrada.")
            self.btn_prev.setEnabled(False)
            self.btn_next.setEnabled(False)
            self.lbl_contador.setText("0/0")

    def carregar_imagem(self, indice):
        if not self.lista_fotos: return
        self.indice_atual = indice % len(self.lista_fotos)
        caminho = self.lista_fotos[self.indice_atual]
        
        pixmap = QPixmap(caminho)
        if not pixmap.isNull():
            pix_scaled = pixmap.scaled(800, 600, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.lbl_imagem.setPixmap(pix_scaled)
            self.lbl_imagem.setText("")
        else:
            self.lbl_imagem.setText("Erro ao carregar imagem.")

        self.lbl_contador.setText(f"Foto {self.indice_atual + 1} de {len(self.lista_fotos)}")
        tem_nav = len(self.lista_fotos) > 1
        self.btn_prev.setEnabled(tem_nav)
        self.btn_next.setEnabled(tem_nav)

    def foto_anterior(self): self.carregar_imagem(self.indice_atual - 1)
    def foto_proxima(self): self.carregar_imagem(self.indice_atual + 1)

    # --- ABA ANEXOS ---
    def setup_aba_anexos(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        layout.addWidget(QLabel("Arquivos vinculados ao imóvel (Duplo clique para abrir):"))

        self.list_anexos = QListWidget()
        self.list_anexos.setAlternatingRowColors(True)
        self.list_anexos.itemDoubleClicked.connect(self.abrir_anexo)
        layout.addWidget(self.list_anexos)

        hbox_files = QHBoxLayout()
        btn_add = QPushButton("➕ Incluir Documento")
        btn_add.clicked.connect(self.adicionar_anexo)
        btn_open_dir = QPushButton("📂 Abrir Pasta")
        btn_open_dir.clicked.connect(self.abrir_pasta_anexos)
        btn_refresh = QPushButton("🔄 Atualizar")
        btn_refresh.clicked.connect(self.carregar_lista_anexos)

        hbox_files.addWidget(btn_add)
        hbox_files.addWidget(btn_open_dir)
        hbox_files.addWidget(btn_refresh)
        layout.addLayout(hbox_files)

        self.base_anexos_path = r"S:\geomap\geomap_imob\imobiliario_geomap"
        self.carregar_lista_anexos()

    def get_path_imovel(self):
        if not self.inscricao_limpa: return None
        return os.path.join(self.base_anexos_path, self.inscricao_limpa)

    def carregar_lista_anexos(self):
        self.list_anexos.clear()
        path_imovel = self.get_path_imovel()
        
        if not os.path.exists(self.base_anexos_path):
            self.list_anexos.addItem("ERRO: Unidade de rede S:\\ não encontrada.")
            return

        if not path_imovel or not os.path.exists(path_imovel):
            self.list_anexos.addItem("Nenhuma pasta de anexos criada.")
            return

        try:
            arquivos = os.listdir(path_imovel)
            arquivos_filtrados = [f for f in arquivos if os.path.isfile(os.path.join(path_imovel, f))]
            if not arquivos_filtrados:
                self.list_anexos.addItem("Pasta vazia.")
            else:
                for arq in arquivos_filtrados:
                    self.list_anexos.addItem(QListWidgetItem(arq))
        except Exception as e:
            self.list_anexos.addItem(f"Erro: {str(e)}")

    def adicionar_anexo(self):
        if not self.inscricao_limpa:
            QMessageBox.warning(self, "Aviso", "Imóvel sem inscrição válida.")
            return

        filename, _ = QFileDialog.getOpenFileName(self, "Selecione o documento")
        if not filename: return

        path_imovel = self.get_path_imovel()
        try:
            if not os.path.exists(path_imovel):
                os.makedirs(path_imovel)
            
            nome_arquivo = os.path.basename(filename)
            destino = os.path.join(path_imovel, nome_arquivo)
            if os.path.exists(destino):
                res = QMessageBox.question(self, "Substituir?", f"Arquivo '{nome_arquivo}' já existe. Substituir?", QMessageBox.Yes|QMessageBox.No)
                if res == QMessageBox.No: return

            shutil.copy2(filename, destino)
            QMessageBox.information(self, "Sucesso", "Documento adicionado!")
            self.carregar_lista_anexos()
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha ao adicionar: {str(e)}")

    def abrir_anexo(self, item):
        texto = item.text()
        if "ERRO" in texto or "Nenhuma" in texto or "Pasta vazia" in texto: return
        path = os.path.join(self.get_path_imovel(), texto)
        if os.path.exists(path): QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def abrir_pasta_anexos(self):
        path = self.get_path_imovel()
        if path and os.path.exists(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            if os.path.exists(self.base_anexos_path):
                QMessageBox.information(self, "Info", "Pasta não existe. Abrindo raiz.")
                QDesktopServices.openUrl(QUrl.fromLocalFile(self.base_anexos_path))

    # --- ABA HISTÓRICO ATUALIZADA (COM QUEBRA DE LINHA E ORDENAÇÃO AUTOMÁTICA) ---
    def setup_aba_historico(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        
        # Configuração da Tabela
        tabela = QTableWidget()
        tabela.setColumnCount(4)
        tabela.setHorizontalHeaderLabels(["Inscrição", "Data", "Histórico", "Assunto"])
        
        # Habilita quebra de linha para texto longo
        tabela.setWordWrap(True)
        
        # Configuração de Layout das Colunas
        header = tabela.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents) # Inscrição
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents) # Data
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents) # Assunto
        header.setSectionResizeMode(2, QHeaderView.Stretch)          # Histórico
        
        # Configuração de Layout das Linhas (Essencial para WordWrap)
        tabela.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

        tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        tabela.setAlternatingRowColors(True)
        tabela.verticalHeader().setVisible(False)
        
        tabela.setSortingEnabled(False)
        
        layout.addWidget(tabela)

        if self.inscricao == "N/A":
            layout.addWidget(QLabel("Imóvel sem inscrição identificada."))
            return

        # Busca pela camada
        nome_historico = "historico_imob_SMAR" 
        layers = QgsProject.instance().mapLayersByName(nome_historico)
        if not layers:
            layout.addWidget(QLabel(f"Camada '{nome_historico}' não encontrada."))
            return
        
        layer_hist = layers[0]

        try:
            im_busca = self.inscricao_limpa
            features = []
            
            # Validação via IdOrigem
            if im_busca.isdigit():
                expr = f"\"IdOrigem\" = {im_busca}"
                req = QgsFeatureRequest().setFilterExpression(expr)
                features = list(layer_hist.getFeatures(req))
            
            # Fallback (caso IdOrigem seja string)
            if not features:
                expr = f"\"IdOrigem\" = '{self.inscricao}'"
                req = QgsFeatureRequest().setFilterExpression(expr)
                features = list(layer_hist.getFeatures(req))

            tabela.setRowCount(len(features))
            if not features:
                layout.addWidget(QLabel(f"Nenhum histórico para Inscrição (IdOrigem): {im_busca}"))
                return

            for row_idx, feat in enumerate(features):
                def get_val(campo):
                    try:
                        v = feat[campo]
                        return str(v) if v is not None else ""
                    except KeyError:
                        return ""

                val_id_origem = get_val('IdOrigem')
                val_data      = get_val('DtHistorico')
                val_hist      = get_val('Historico')
                val_assunto   = get_val('Assunto')

                tabela.setItem(row_idx, 0, QTableWidgetItem(val_id_origem))
                tabela.setItem(row_idx, 1, QTableWidgetItem(val_data))
                
                item_hist = QTableWidgetItem(val_hist)
                item_hist.setToolTip(val_hist)
                tabela.setItem(row_idx, 2, item_hist)

                tabela.setItem(row_idx, 3, QTableWidgetItem(val_assunto))
            
            # Ajustes Finais
            tabela.resizeRowsToContents()
            tabela.setSortingEnabled(True)

            # --- AJUSTE: ORDENAR PELA DATA (COLUNA 1) ---
            # Qt.DescendingOrder = Mais recente primeiro (geralmente preferido para logs)
            # Use Qt.AscendingOrder se preferir do mais antigo para o mais novo.
            tabela.sortItems(1, Qt.AscendingOrder)

            layout.addWidget(QLabel(f"Registros: {len(features)}"))

        except Exception as e:
            layout.addWidget(QLabel(f"Erro: {str(e)}"))

    def gerar_croqui_local(self):
        fid = self.feature.id()
        self.layer.selectByIds([fid])
        box = self.layer.getFeature(fid).geometry().boundingBox()
        box.scale(1.5)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

        project = QgsProject.instance()
        layout_manager = project.layoutManager()
        nome_layout = "A4 - Croqui de Imovel (IMOBILIARIO)"
        layout = layout_manager.layoutByName(nome_layout)

        if not layout:
            path_qpt = os.path.join(os.path.dirname(__file__), f"{nome_layout}.qpt")
            if os.path.exists(path_qpt):
                layout = QgsPrintLayout(project)
                layout.initializeDefaults()
                layout.setName(nome_layout)
                with open(path_qpt) as f:
                    template_content = f.read()
                from PyQt5.QtXml import QDomDocument
                doc = QDomDocument()
                doc.setContent(template_content)
                layout.loadFromTemplate(doc, QgsReadWriteContext())
                layout_manager.addLayout(layout)
            else:
                iface.messageBar().pushMessage("Erro", f"Layout '{nome_layout}' não encontrado.", level=2)
                return

        atlas = layout.atlas()
        atlas.setCoverageLayer(self.layer)
        atlas.setEnabled(True)
        atlas.setFilterFeatures(True)
        atlas.setFilterExpression(f"$id = {fid}")

        inscricao_limpa = re.sub(r'[\\/*?:"<>|]', "", self.inscricao)
        nome_sugestao = f"CROQUI_{inscricao_limpa}.pdf"
        path_inicial = os.path.join(os.path.expanduser("~"), "Documents", nome_sugestao)
        
        filename, _ = QFileDialog.getSaveFileName(self, "Salvar Croqui", path_inicial, "PDF (*.pdf)")
        if not filename: return

        if atlas.updateFeatures(): 
            atlas.beginRender()
            atlas.seekTo(0)
            exporter = QgsLayoutExporter(layout)
            result = exporter.exportToPdf(filename, QgsLayoutExporter.PdfExportSettings())
            atlas.endRender()
            if result == QgsLayoutExporter.Success:
                iface.messageBar().pushMessage("Sucesso", f"Salvo: {filename}", level=0)
                try: os.startfile(filename)
                except: pass
            else:
                iface.messageBar().pushMessage("Erro", "Erro ao exportar.", level=2)
        else:
             iface.messageBar().pushMessage("Erro", "Erro ao focar no imóvel.", level=2)


# ============================================================================
# 2. FERRAMENTA DE MAPA
# ============================================================================
class ToolSelecionarFicha(QgsMapTool):
    imovel_encontrado = pyqtSignal(object)

    def __init__(self, canvas, layer):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, event):
        point_xy = self.toMapCoordinates(event.pos())
        point_geo = QgsGeometry.fromPointXY(point_xy)
        
        radius = self.canvas.mapUnitsPerPixel() * 2 
        rect = point_geo.buffer(radius, 5).boundingBox()
        request = QgsFeatureRequest().setFilterRect(rect)
        
        found = None
        for feat in self.layer.getFeatures(request):
            if feat.geometry().contains(point_geo):
                found = feat
                break 
        
        if not found:
            iterator = self.layer.getFeatures(request)
            try:
                found = next(iterator)
            except StopIteration:
                pass

        if found:
            self.imovel_encontrado.emit(found)
        else:
            iface.messageBar().pushMessage("Seleção", "Clique dentro do lote.", level=1, duration=1)

# ============================================================================
# 3. INTERFACE PRINCIPAL
# ============================================================================
class BuscaImovelDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Busca de Imóveis")
        self.setAllowedAreas(Qt.RightDockWidgetArea | Qt.LeftDockWidgetArea)
        self.main_widget = QWidget()
        self.setWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        self.setup_ui()
        self.tool_selecao = None

    def setup_ui(self):
        gb = QGroupBox("Pesquisa")
        lb = QVBoxLayout(gb)
        
        self.combo = QComboBox()
        self.combo.addItems(["Inscrição", "Endereço", "CPF/CNPJ", "Proprietário"])
        lb.addWidget(QLabel("Tipo de Busca:"))
        lb.addWidget(self.combo)

        self.input_busca = QLineEdit()
        self.input_busca.setPlaceholderText("Digite para buscar...")
        self.input_busca.returnPressed.connect(self.buscar)
        lb.addWidget(self.input_busca)

        self.check_exata = QCheckBox("Busca Exata")
        lb.addWidget(self.check_exata)
        
        btn = QPushButton("Buscar")
        btn.clicked.connect(self.buscar)
        lb.addWidget(btn)
        self.layout.addWidget(gb)

        self.tabela = QTableWidget()
        self.tabela.setColumnCount(3)
        self.tabela.setHorizontalHeaderLabels(["Inscrição", "Proprietário", "Endereço"])
        
        self.tabela.setSortingEnabled(True) 
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive) 
        self.tabela.horizontalHeader().setStretchLastSection(True) 

        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.doubleClicked.connect(self.abrir_ficha_por_item)
        self.layout.addWidget(self.tabela)

        hbox = QHBoxLayout()
        btn_zoom = QPushButton("Zoom")
        btn_zoom.clicked.connect(lambda: self.acao_tabela(self.zoom_para_imovel))
        hbox.addWidget(btn_zoom)
        btn_ficha = QPushButton("Ficha")
        btn_ficha.clicked.connect(lambda: self.acao_tabela(self.abrir_ficha_por_item))
        hbox.addWidget(btn_ficha)
        self.layout.addLayout(hbox)
        
        btn_mapa = QPushButton("Selecionar no Mapa")
        btn_mapa.clicked.connect(self.ativar_ferramenta_mapa)
        self.layout.addWidget(btn_mapa)

        btn_croqui = QPushButton("Gerar Croqui (PDF)")
        btn_croqui.setStyleSheet("font-weight: bold; padding: 5px; margin-top: 10px;")
        btn_croqui.clicked.connect(lambda: self.acao_tabela(self.exportar_croqui))
        self.layout.addWidget(btn_croqui)

    def get_layer(self):
        nome_alvo = "IMOBILIARIO"
        layers = QgsProject.instance().mapLayersByName(nome_alvo)
        if layers: return layers[0]
        iface.messageBar().pushMessage("Erro", f"Camada '{nome_alvo}' não encontrada.", level=2)
        return None

    def find_col(self, layer, keywords, exclude_keywords=[]):
        for f in layer.fields():
            fn_norm = normalize_str(f.name())
            is_excluded = False
            for exc in exclude_keywords:
                if exc in fn_norm:
                    is_excluded = True
                    break
            if is_excluded: continue
            for k in keywords:
                if k in fn_norm: return f.name()
        return None

    def buscar(self):
        texto = self.input_busca.text().strip()
        layer = self.get_layer()
        if not layer or not texto: return

        tipo = self.combo.currentText()
        exata = self.check_exata.isChecked()
        
        self.tabela.setSortingEnabled(False)
        self.tabela.setRowCount(0)
        
        expr = ""
        if tipo == "Inscrição":
            col = self.find_col(layer, ['inscricao', 'im'])
            if not col: return self.aviso_coluna("Inscrição")
            op = "=" if exata else "ILIKE"
            val = f"'{texto}'" if exata else f"'%{texto}%'"
            expr = f"\"{col}\" {op} {val}"

        elif tipo == "Endereço":
            col = self.find_col(layer, ['bd_smar_imovel_endereco', 'endereco'])
            if not col: col = self.find_col(layer, ['logradouro', 'rua']) 
            if not col: return self.aviso_coluna("Endereço")
            expr = f"\"{col}\" ILIKE '%{texto}%'"

        elif tipo == "Proprietário":
            col = self.find_col(layer, ['proprietario', 'prop', 'nome'], exclude_keywords=['cpf', 'cnpj', 'doc'])
            if not col: return self.aviso_coluna("Proprietário")
            op = "=" if exata else "ILIKE"
            val = f"'{texto}'" if exata else f"'%{texto}%'"
            expr = f"\"{col}\" {op} {val}"

        elif tipo == "CPF/CNPJ":
            col = self.find_col(layer, ['cpf', 'cnpj', 'doc'])
            if not col: return self.aviso_coluna("CPF/CNPJ")
            nums = re.sub(r'[^0-9]', '', texto)
            if not nums: return
            op = "=" if exata else "LIKE"
            val = f"'{nums}'" if exata else f"'%{nums}%'"
            expr = f"regexp_replace(\"{col}\", '[^0-9]', '') {op} {val}"

        try:
            req = QgsFeatureRequest().setFilterExpression(expr)
            feats = list(layer.getFeatures(req))
            self.tabela.setRowCount(len(feats))
            
            c_insc = self.find_col(layer, ['inscricao', 'im'])
            c_prop = self.find_col(layer, ['proprietario', 'prop'], exclude_keywords=['cpf', 'cnpj', 'doc'])
            c_end  = self.find_col(layer, ['bd_smar_imovel_endereco', 'endereco'])
            if not c_end: c_end = self.find_col(layer, ['logradouro'])

            for r, f in enumerate(feats):
                v_insc = str(f[c_insc]) if c_insc else ""
                v_prop = str(f[c_prop]) if c_prop else ""
                v_end = str(f[c_end]) if c_end else ""

                self.tabela.setItem(r, 0, QTableWidgetItem(v_insc))
                self.tabela.setItem(r, 1, QTableWidgetItem(v_prop))
                self.tabela.setItem(r, 2, QTableWidgetItem(v_end))
                self.tabela.item(r, 0).setData(Qt.UserRole, f.id())

            self.tabela.setSortingEnabled(True)
            if not feats:
                iface.messageBar().pushMessage("Busca", "Nenhum resultado.", level=1)
        except Exception as e:
            iface.messageBar().pushMessage("Erro", f"Falha na query: {e}", level=2)

    def aviso_coluna(self, nome):
        iface.messageBar().pushMessage("Erro", f"Coluna de '{nome}' não identificada na camada.", level=2)

    def acao_tabela(self, func):
        sel = self.tabela.selectedItems()
        if not sel: return
        func(sel[0])

    def zoom_para_imovel(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        layer.selectByIds([fid])
        box = layer.boundingBoxOfSelected()
        box.scale(1.5)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

    def abrir_ficha_por_item(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        self.abrir_dialogo_ficha(layer.getFeature(fid))

    def abrir_dialogo_ficha(self, feature):
        layer = self.get_layer()
        if not layer: return
        dialog = FichaImovelDialog(feature, layer, self)
        dialog.exec_()

    def ativar_ferramenta_mapa(self):
        layer = self.get_layer()
        if not layer: return
        self.tool_selecao = ToolSelecionarFicha(iface.mapCanvas(), layer)
        self.tool_selecao.imovel_encontrado.connect(self.abrir_dialogo_ficha)
        iface.mapCanvas().setMapTool(self.tool_selecao)
        iface.messageBar().pushMessage("Ferramenta Ativa", "Clique em um imóvel.", level=0, duration=3)

    def exportar_croqui(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        
        layer.selectByIds([fid])
        box = layer.getFeature(fid).geometry().boundingBox()
        box.scale(1.2)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

        project = QgsProject.instance()
        layout_manager = project.layoutManager()
        nome_layout = "A4 - Croqui de Imovel (IMOBILIARIO)"
        layout = layout_manager.layoutByName(nome_layout)

        if not layout:
            path_qpt = os.path.join(os.path.dirname(__file__), f"{nome_layout}.qpt")
            if os.path.exists(path_qpt):
                layout = QgsPrintLayout(project)
                layout.initializeDefaults()
                layout.setName(nome_layout)
                with open(path_qpt) as f:
                    template_content = f.read()
                from PyQt5.QtXml import QDomDocument
                doc = QDomDocument()
                doc.setContent(template_content)
                layout.loadFromTemplate(doc, QgsReadWriteContext())
                layout_manager.addLayout(layout)
            else:
                iface.messageBar().pushMessage("Erro", f"Layout '{nome_layout}' não encontrado.", level=2)
                return

        atlas = layout.atlas()
        atlas.setCoverageLayer(layer)
        atlas.setEnabled(True)
        atlas.setFilterFeatures(True)
        atlas.setFilterExpression(f"$id = {fid}")

        row = item.row()
        inscricao_raw = self.tabela.item(row, 0).text()
        inscricao_limpa = re.sub(r'[\\/*?:"<>|]', "", inscricao_raw)
        
        nome_sugestao = f"CROQUI_{inscricao_limpa}.pdf"
        path_inicial = os.path.join(os.path.expanduser("~"), "Documents", nome_sugestao)
        
        filename, _ = QFileDialog.getSaveFileName(self, "Salvar Croqui", path_inicial, "PDF (*.pdf)")
        if not filename: return

        if atlas.updateFeatures(): 
            atlas.beginRender()
            atlas.seekTo(0)
            exporter = QgsLayoutExporter(layout)
            result = exporter.exportToPdf(filename, QgsLayoutExporter.PdfExportSettings())
            atlas.endRender()
            if result == QgsLayoutExporter.Success:
                iface.messageBar().pushMessage("Sucesso", f"Salvo: {filename}", level=0)
                try: os.startfile(filename)
                except: pass
            else:
                iface.messageBar().pushMessage("Erro", "Erro ao exportar.", level=2)
        else:
             iface.messageBar().pushMessage("Erro", "Erro ao focar no imóvel.", level=2)