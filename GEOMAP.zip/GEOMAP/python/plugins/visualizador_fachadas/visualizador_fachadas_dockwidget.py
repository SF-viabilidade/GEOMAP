import os
from qgis.core import QgsProject
from qgis.gui import QgsDockWidget
from qgis.utils import iface
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
                             QScrollArea, QMessageBox, QSizePolicy)
from PyQt5.QtCore import Qt, QMetaObject, QCoreApplication, QUrl, pyqtSignal
from PyQt5.QtGui import QDesktopServices, QPixmap, QImage

# ============================================================================
# INTERFACE GRÁFICA (Embutida para não depender de arquivos .ui externos)
# ============================================================================
class Ui_PhotoDock(object):
    def setupUi(self, DockWidget):
        DockWidget.setObjectName("DockWidget")
        DockWidget.resize(400, 650)
        DockWidget.setWindowTitle("Visualizador de Fachada")
        
        self.dockWidgetContents = QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        
        self.verticalLayout = QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName("verticalLayout")
        
        # 1. Label de Informação (Inscrição)
        self.lbl_info = QLabel(self.dockWidgetContents)
        self.lbl_info.setStyleSheet("font-weight: bold; font-size: 14px; color: #2c3e50; margin-bottom: 5px;")
        self.lbl_info.setAlignment(Qt.AlignCenter)
        self.lbl_info.setText("Selecione um imóvel...")
        self.verticalLayout.addWidget(self.lbl_info)
        
        # 2. Área da Imagem
        self.scrollArea = QScrollArea(self.dockWidgetContents)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setAlignment(Qt.AlignCenter)
        
        self.lbl_image = QLabel()
        self.lbl_image.setAlignment(Qt.AlignCenter)
        self.lbl_image.setText("Sem imagem")
        self.lbl_image.setStyleSheet("background-color: #ecf0f1; border: 1px dashed #bdc3c7;")
        
        self.scrollArea.setWidget(self.lbl_image)
        self.verticalLayout.addWidget(self.scrollArea)
        
        # 3. Label com nome do arquivo
        self.lbl_filename = QLabel(self.dockWidgetContents)
        self.lbl_filename.setStyleSheet("font-size: 10px; color: #7f8c8d;")
        self.lbl_filename.setAlignment(Qt.AlignCenter)
        self.verticalLayout.addWidget(self.lbl_filename)
        
        # --- CONTROLES DE NAVEGAÇÃO ---
        self.nav_layout = QHBoxLayout()
        
        self.btn_prev = QPushButton("< Anterior", self.dockWidgetContents)
        self.nav_layout.addWidget(self.btn_prev)
        
        self.lbl_counter = QLabel("0 de 0", self.dockWidgetContents)
        self.lbl_counter.setAlignment(Qt.AlignCenter)
        self.lbl_counter.setStyleSheet("font-weight: bold;")
        self.nav_layout.addWidget(self.lbl_counter)
        
        self.btn_next = QPushButton("Próximo >", self.dockWidgetContents)
        self.nav_layout.addWidget(self.btn_next)
        
        self.verticalLayout.addLayout(self.nav_layout)
        
        # 4. Botão abrir original
        self.btn_open = QPushButton("🔍 Abrir Foto Original", self.dockWidgetContents)
        self.btn_open.setStyleSheet("background-color: #2980b9; color: white; font-weight: bold; padding: 8px;")
        self.verticalLayout.addWidget(self.btn_open)
        
        DockWidget.setWidget(self.dockWidgetContents)
        QMetaObject.connectSlotsByName(DockWidget)

# ============================================================================
# LÓGICA DO PLUGIN
# ============================================================================
class VisualizadorFachadasDockWidget(QgsDockWidget, Ui_PhotoDock):
    """
    Classe principal do DockWidget do Plugin.
    O nome desta classe deve bater com o import no arquivo principal (__init__.py ou visualizador_fachadas.py)
    """
    
    # Sinal para avisar o QGIS quando o plugin fechar
    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        super(VisualizadorFachadasDockWidget, self).__init__(parent)
        self.setupUi(self)
        
        # --- CONFIGURAÇÃO ---
        self.root_dir = r"P:\Ortofotos 2023\05. Foto-Fachada para Entrega"
        self.id_field = "inscricao"
        self.valid_extensions = ('.jpg', '.jpeg', '.png', '.bmp', '.tif')
        # --------------------

        # Variáveis de Estado
        self.photo_list = []      
        self.current_index = 0    
        
        if not os.path.exists(self.root_dir):
            self.lbl_info.setText("Erro: Caminho P:\\ não encontrado")
            self.lbl_info.setStyleSheet("color: red; font-weight: bold;")

        # Conexões
        self.btn_open.clicked.connect(self.open_original_file)
        self.btn_prev.clicked.connect(self.show_prev_photo)
        self.btn_next.clicked.connect(self.show_next_photo)
        
        # Conecta ao evento do canvas
        iface.mapCanvas().selectionChanged.connect(self.selection_changed)
        
        # Estado inicial
        self.reset_ui("Selecione um imóvel...")

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def selection_changed(self, layer=None):
        # Se o plugin estiver fechado/invisível, não faz nada
        if not self.isVisible(): return

        layer = iface.activeLayer()
        if not layer or layer.selectedFeatureCount() != 1:
            self.reset_ui("Selecione UM imóvel")
            return

        feature = layer.selectedFeatures()[0]
        try:
            raw_id = feature[self.id_field]
            if raw_id is None:
                self.reset_ui("Inscrição Nula")
                return
                
            inscricao = str(raw_id).strip()
            # Limpeza do ID
            safe_id = "".join([c for c in inscricao if c.isalnum() or c in ('-', '_')])
            
            self.lbl_info.setText(f"Imóvel: {safe_id}")
            
            # 1. Busca TODAS as fotos
            self.photo_list = self.find_photos(safe_id)
            self.current_index = 0
            
            # 2. Atualiza a visualização
            if self.photo_list:
                self.update_view()
            else:
                self.reset_ui(f"Imóvel: {safe_id}", status="Nenhuma foto encontrada")

        except KeyError:
            self.reset_ui("Erro: Campo 'inscricao' inexistente")

    def find_photos(self, doc_id):
        matches = []
        if not os.path.exists(self.root_dir):
            return matches
            
        try:
            files = os.listdir(self.root_dir)
            for f in files:
                if f.lower().endswith(self.valid_extensions):
                    name_no_ext = os.path.splitext(f)[0]
                    
                    if name_no_ext == doc_id or \
                       name_no_ext.startswith(doc_id + "_") or \
                       name_no_ext.startswith(doc_id + "-") or \
                       name_no_ext.startswith(doc_id + " "):
                        
                        full_path = os.path.join(self.root_dir, f)
                        matches.append(full_path)
            
            return sorted(matches)
        except Exception:
            return matches

    def update_view(self):
        if not self.photo_list: return

        path = self.photo_list[self.current_index]
        
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            w = self.dockWidgetContents.width() - 40
            if w < 100: w = 200
            scaled_pixmap = pixmap.scaledToWidth(w, Qt.SmoothTransformation)
            self.lbl_image.setPixmap(scaled_pixmap)
        else:
            self.lbl_image.setText("Erro na imagem")

        filename = os.path.basename(path)
        self.lbl_filename.setText(filename)
        
        total = len(self.photo_list)
        self.lbl_counter.setText(f"{self.current_index + 1} de {total}")
        
        self.btn_prev.setEnabled(self.current_index > 0)
        self.btn_next.setEnabled(self.current_index < total - 1)
        self.btn_open.setEnabled(True)

    def show_next_photo(self):
        if self.current_index < len(self.photo_list) - 1:
            self.current_index += 1
            self.update_view()

    def show_prev_photo(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.update_view()

    def reset_ui(self, title, status="Sem imagem"):
        self.lbl_info.setText(title)
        self.lbl_image.clear()
        self.lbl_image.setText(status)
        self.lbl_filename.clear()
        self.lbl_counter.setText("0 de 0")
        
        self.photo_list = []
        self.current_index = 0
        
        self.btn_open.setEnabled(False)
        self.btn_prev.setEnabled(False)
        self.btn_next.setEnabled(False)

    def open_original_file(self):
        if self.photo_list:
            path = self.photo_list[self.current_index]
            if os.path.exists(path):
                QDesktopServices.openUrl(QUrl.fromLocalFile(path))