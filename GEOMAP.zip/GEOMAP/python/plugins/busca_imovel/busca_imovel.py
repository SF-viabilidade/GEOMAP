# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from .interface_imovel import BuscaImovelDock

class BuscaImovelPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock_widget = None
        self.action = None

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'icon.png')
        
        self.action = QAction(QIcon(icon_path), "Busca Imóveis", self.iface.mainWindow())
        self.action.setObjectName("BuscaImovelAction")
        self.action.setCheckable(True)
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Busca Imóveis", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Busca Imóveis", self.action)
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

    def run(self):
        if not self.dock_widget:
            self.dock_widget = BuscaImovelDock(self.iface.mainWindow())
            self.dock_widget.visibilityChanged.connect(self.action.setChecked)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
        
        if self.action.isChecked(): self.dock_widget.show()
        else: self.dock_widget.hide()