# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt

# A IMPORTAÇÃO ABAIXO É VITAL:
# Garante que o QGIS encontre a classe BuscaImovelDock que está no seu arquivo interface_imovel.py
from .interface_imovel import BuscaImovelDock

class BuscaImovelPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock_widget = None
        self.action = None

    def initGui(self):
        # Configuração do Ícone via caminho absoluto (mais seguro)
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'icon.png')
        
        # 1. Cria a Ação (Botão)
        self.action = QAction(
            QIcon(icon_path), 
            "Busca Imóveis", 
            self.iface.mainWindow()
        )
        self.action.setObjectName("BuscaImovelAction")
        self.action.setCheckable(True)
        
        # 2. Conecta o clique à função run
        self.action.triggered.connect(self.run)

        # 3. Adiciona na Barra de Ferramentas e no Menu
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Busca Imóveis", self.action)

    def unload(self):
        # Remove os vestígios do plugin ao desativar
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Busca Imóveis", self.action)
        
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

    def run(self):
        """Lógica para abrir/fechar o painel lateral"""
        if not self.dock_widget:
            # Aqui é onde o erro acontecia. Agora a classe está importada corretamente.
            self.dock_widget = BuscaImovelDock(self.iface.mainWindow())
            
            # Conecta o sinal de visibilidade para desmarcar o botão se fechar no 'X'
            self.dock_widget.visibilityChanged.connect(self.action.setChecked)
            
            # Adiciona o dock na lateral direita
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
        
        # Alterna a exibição
        if self.action.isChecked():
            self.dock_widget.show()
        else:
            self.dock_widget.hide()