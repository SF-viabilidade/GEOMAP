# ARQUIVO: interface_imovel.py
import os
import re
import glob
import shutil
import unicodedata
from PyQt5.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, 
                             QHeaderView, QAbstractItemView, QDialog, 
                             QGroupBox, QTabWidget, QComboBox, QCheckBox, 
                             QFileDialog, QSizePolicy, QListWidget, QListWidgetItem, 
                             QMessageBox, QGraphicsView, QGraphicsScene,
                             QGraphicsPixmapItem)
from PyQt5.QtCore import Qt, pyqtSignal, QUrl, QThread
from PyQt5.QtGui import QPixmap, QDesktopServices

from qgis.core import (QgsProject, QgsFeatureRequest, QgsLayoutExporter, 
                       QgsGeometry, QgsReadWriteContext, QgsPrintLayout,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsLayoutItemLabel)
from qgis.gui import QgsMapTool
from qgis.utils import iface

# ============================================================================
# DICIONÁRIO DE CAMADAS DE FUNDO E TEXTOS PARA O LAYOUT
# ============================================================================
OPCOES_FUNDO = {
    "Ortofoto fev-2023": "Ortofoto Valinhos - Fevereiro/2023",
    "Ortofoto mar-2018": "Ortofoto Valinhos - Março/2018",
    "Ortofoto jul-2013": "Ortofoto Valinhos - Julho/2013",
    "Google Satellite": "Imagem: Google Satellite"
}

# ============================================================================
# TEMA VISUAL (QSS) - ESTILO MODERNO
# ============================================================================
MODERN_STYLE = """
QWidget {
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
    color: #333333;
}
QPushButton {
    background-color: #005A9E;
    color: white;
    border-radius: 4px;
    padding: 6px 12px;
    font-weight: bold;
    border: none;
}
QPushButton:hover { background-color: #106EBE; }
QPushButton:pressed { background-color: #004578; }
QPushButton:disabled { background-color: #cccccc; color: #888888; }
QPushButton#btnAcaoSecundaria { background-color: #E1DFDD; color: #333333; }
QPushButton#btnAcaoSecundaria:hover { background-color: #D2D0CE; }

QLineEdit, QComboBox {
    padding: 6px;
    border: 1px solid #8A8886;
    border-radius: 4px;
    background-color: #FFFFFF;
}
QLineEdit:focus, QComboBox:focus { border: 1px solid #005A9E; }

QTableWidget {
    gridline-color: #E1DFDD;
    border: 1px solid #C8C6C4;
    border-radius: 4px;
    selection-background-color: #CCE3F5;
    selection-color: #333333;
    background-color: #FFFFFF;
    alternate-background-color: #F8F8F8;
}
QHeaderView::section {
    background-color: #F3F2F1;
    padding: 6px;
    border: none;
    border-right: 1px solid #E1DFDD;
    border-bottom: 1px solid #E1DFDD;
    font-weight: bold;
}
QTabWidget::pane {
    border: 1px solid #C8C6C4;
    border-radius: 4px;
    top: -1px;
    background-color: #FFFFFF;
}
QTabBar::tab {
    background: #F3F2F1;
    border: 1px solid #C8C6C4;
    padding: 8px 20px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background: #FFFFFF;
    border-bottom-color: #FFFFFF;
    font-weight: bold;
    color: #005A9E;
}
QGroupBox {
    font-weight: bold;
    border: 1px solid #C8C6C4;
    border-radius: 5px;
    margin-top: 15px;
    padding-top: 15px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 5px;
    left: 10px;
    color: #005A9E;
}
"""

# ============================================================================
# FUNÇÕES UTILITÁRIAS
# ============================================================================
def normalize_str(s):
    if not s: return ""
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) 
                   if unicodedata.category(c) != 'Mn').lower()

class FotoBuscaThread(QThread):
    resultado_pronto = pyqtSignal(list)
    def __init__(self, inscricao_limpa, base_path):
        super().__init__()
        self.inscricao_limpa = inscricao_limpa
        self.base_path = base_path
    def run(self):
        lista_fotos = []
        if os.path.exists(self.base_path) and self.inscricao_limpa:
            padroes = [
                os.path.join(self.base_path, f"{self.inscricao_limpa}.*"),
                os.path.join(self.base_path, f"{self.inscricao_limpa}_*.*")
            ]
            encontrados = []
            for p in padroes: encontrados.extend(glob.glob(p))
            exts = ['.jpg', '.jpeg', '.png', '.bmp']
            lista_fotos = sorted(list(set([f for f in encontrados if os.path.splitext(f)[1].lower() in exts])))
        self.resultado_pronto.emit(lista_fotos)

class FotoViewer(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setStyleSheet("background-color: #F3F2F1; border: 1px solid #C8C6C4; border-radius: 5px;")
        self.setMinimumHeight(450)
        self.pixmap_item = None
        self._is_panning = False
        self._pan_start = None

    def show_text(self, text):
        self.scene.clear()
        self.pixmap_item = None
        text_item = self.scene.addText(text)
        text_item.setDefaultTextColor(Qt.darkGray)
        self.setSceneRect(0, 0, 400, 300)
        text_item.setPos((400 - text_item.boundingRect().width()) / 2, (300 - text_item.boundingRect().height()) / 2)
        self.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def set_image(self, pixmap):
        self.scene.clear()
        self.pixmap_item = QGraphicsPixmapItem(pixmap)
        self.pixmap_item.setTransformationMode(Qt.SmoothTransformation)
        self.scene.addItem(self.pixmap_item)
        self.setSceneRect(0, 0, pixmap.width(), pixmap.height())
        self.fit_in_view()

    def fit_in_view(self):
        if self.pixmap_item:
            self.fitInView(self.sceneRect(), Qt.KeepAspectRatio)

    def wheelEvent(self, event):
        if not self.pixmap_item: return
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        if event.angleDelta().y() > 0: self.scale(1.25, 1.25)
        else: self.scale(0.8, 0.8)

    def zoom_in(self):
        if not self.pixmap_item: return
        self.setTransformationAnchor(QGraphicsView.AnchorViewCenter)
        self.scale(1.25, 1.25)

    def zoom_out(self):
        if not self.pixmap_item: return
        self.setTransformationAnchor(QGraphicsView.AnchorViewCenter)
        self.scale(0.8, 0.8)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._is_panning = True
            self._pan_start = event.pos()
            self.setCursor(Qt.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._is_panning = False
            self.setCursor(Qt.ArrowCursor)
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        if self._is_panning and self._pan_start is not None:
            delta = event.pos() - self._pan_start
            h_bar = self.horizontalScrollBar()
            v_bar = self.verticalScrollBar()
            h_bar.setValue(h_bar.value() - delta.x())
            v_bar.setValue(v_bar.value() - delta.y())
            self._pan_start = event.pos()
        super().mouseMoveEvent(event)

# ============================================================================
# 1. CLASSE DA FICHA CADASTRAL (DIÁLOGO)
# ============================================================================
class FichaImovelDialog(QDialog):
    def __init__(self, feature, layer, parent=None):
        super().__init__(parent)
        self.feature = feature
        self.layer = layer 
        self.setStyleSheet(MODERN_STYLE)
        
        self.inscricao = "N/A"
        for field in layer.fields():
            name_norm = normalize_str(field.name())
            if 'inscricao' in name_norm or name_norm == 'im':
                val = feature[field.name()]
                if val: self.inscricao = str(val)
                break
        
        self.inscricao_limpa = re.sub(r'[^0-9]', '', self.inscricao)
        self.setWindowTitle(f"Ficha do Imóvel: {self.inscricao}")
        self.setMinimumWidth(1000)
        self.setMinimumHeight(750)

        layout_principal = QVBoxLayout(self)
        
        header_layout = QHBoxLayout()
        lbl_titulo = QLabel(f"🏢 Inscrição: <b>{self.inscricao}</b>")
        lbl_titulo.setStyleSheet("font-size: 18px; color: #005A9E;")
        header_layout.addWidget(lbl_titulo)
        header_layout.addStretch()
        
        btn_street_view = QPushButton("🗺️ Abrir Street View")
        btn_street_view.clicked.connect(self.abrir_street_view)
        header_layout.addWidget(btn_street_view)
        layout_principal.addLayout(header_layout)

        self.tabs = QTabWidget()
        layout_principal.addWidget(self.tabs)

        self.tab_dados = QWidget()
        self.setup_aba_dados(self.tab_dados)
        self.tabs.addTab(self.tab_dados, "📄 Dados Gerais")

        self.tab_fotos = QWidget()
        self.setup_aba_fotos(self.tab_fotos)
        self.tabs.addTab(self.tab_fotos, "🖼️ Fachada")

        self.tab_anexos = QWidget()
        self.setup_aba_anexos(self.tab_anexos)
        self.tabs.addTab(self.tab_anexos, "📎 Anexos")

        self.tab_historico = QWidget()
        self.setup_aba_historico(self.tab_historico)
        self.tabs.addTab(self.tab_historico, "🕒 Histórico")

        # Rodapé com Controle de Fundo e Impressão
        hbox_btns = QHBoxLayout()
        
        lbl_fundo = QLabel("🖼️ Imagem de Fundo:")
        lbl_fundo.setStyleSheet("font-weight: bold;")
        hbox_btns.addWidget(lbl_fundo)
        
        self.combo_fundo = QComboBox()
        self.combo_fundo.addItems(list(OPCOES_FUNDO.keys()))
        hbox_btns.addWidget(self.combo_fundo)
        
        hbox_btns.addSpacing(20)
        
        self.btn_croqui = QPushButton("🖨️ Gerar Croqui (PDF)")
        self.btn_croqui.clicked.connect(self.gerar_croqui_local)
        hbox_btns.addWidget(self.btn_croqui)

        self.btn_ficha_pdf = QPushButton("📋 Gerar Ficha (PDF)")
        self.btn_ficha_pdf.clicked.connect(self.gerar_ficha_local)
        hbox_btns.addWidget(self.btn_ficha_pdf)
        
        hbox_btns.addStretch()
        
        btn_fechar = QPushButton("❌ Fechar")
        btn_fechar.setObjectName("btnAcaoSecundaria")
        btn_fechar.clicked.connect(self.accept)
        hbox_btns.addWidget(btn_fechar)

        layout_principal.addLayout(hbox_btns)

    def abrir_street_view(self):
        geom = self.feature.geometry()
        if geom.isNull():
            QMessageBox.warning(self, "Aviso", "Imóvel sem geometria válida.")
            return
        centroid = geom.centroid().asPoint()
        crs_src = self.layer.crs()
        crs_dest = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(crs_src, crs_dest, QgsProject.instance())
        try:
            pt_wgs = transform.transform(centroid)
            url = f"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint={pt_wgs.y()},{pt_wgs.x()}"
            QDesktopServices.openUrl(QUrl(url))
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha ao calcular coordenadas:\n{str(e)}")

    def setup_aba_dados(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        table = QTableWidget()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Atributo", "Informação Cadastral"])
        table.setAlternatingRowColors(True)
        header = table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setStretchLastSection(True)
        table.setColumnWidth(0, 250)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        fields = self.layer.fields()
        table.setRowCount(len(fields))
        for i, field in enumerate(fields):
            nome_campo = field.name()
            val = self.feature[nome_campo] if nome_campo in self.feature.attributeMap() else ""
            item_key = QTableWidgetItem(nome_campo)
            font = item_key.font()
            font.setBold(True)
            item_key.setFont(font)
            table.setItem(i, 0, item_key)
            table.setItem(i, 1, QTableWidgetItem(str(val) if val is not None else ""))
        layout.addWidget(table)

    def setup_aba_fotos(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        self.viewer = FotoViewer()
        self.viewer.show_text("A procurar fotos na rede...")
        layout.addWidget(self.viewer)
        hbox_nav = QHBoxLayout()
        self.btn_zoom_out = QPushButton("➖")
        self.btn_zoom_out.clicked.connect(self.viewer.zoom_out)
        self.btn_fit = QPushButton("🔳")
        self.btn_fit.clicked.connect(self.viewer.fit_in_view)
        self.btn_zoom_in = QPushButton("➕")
        self.btn_zoom_in.clicked.connect(self.viewer.zoom_in)
        self.btn_prev = QPushButton("◀ Anterior")
        self.btn_prev.clicked.connect(self.foto_anterior)
        self.btn_next = QPushButton("Próxima ▶")
        self.btn_next.clicked.connect(self.foto_proxima)
        self.lbl_contador = QLabel("0 / 0")
        hbox_nav.addWidget(self.btn_zoom_out)
        hbox_nav.addWidget(self.btn_fit)
        hbox_nav.addWidget(self.btn_zoom_in)
        hbox_nav.addStretch()
        hbox_nav.addWidget(self.btn_prev)
        hbox_nav.addWidget(self.lbl_contador)
        hbox_nav.addWidget(self.btn_next)
        hbox_nav.addStretch()
        layout.addLayout(hbox_nav)
        self.lista_fotos = []
        self.indice_atual = 0
        base_path = r"P:\Ortofotos 2023\05. Foto-Fachada para Entrega"
        self.thread_fotos = FotoBuscaThread(self.inscricao_limpa, base_path)
        self.thread_fotos.resultado_pronto.connect(self.ao_terminar_busca_fotos)
        self.thread_fotos.start()

    def ao_terminar_busca_fotos(self, lista):
        self.lista_fotos = lista
        if self.lista_fotos:
            self.carregar_imagem(0)
        else:
            self.viewer.show_text("Nenhuma foto encontrada.")
            self.lbl_contador.setText("0 / 0")

    def carregar_imagem(self, indice):
        self.indice_atual = indice % len(self.lista_fotos)
        pixmap = QPixmap(self.lista_fotos[self.indice_atual])
        if not pixmap.isNull():
            self.viewer.set_image(pixmap)
        self.lbl_contador.setText(f"Foto {self.indice_atual + 1} de {len(self.lista_fotos)}")

    def foto_anterior(self):
        self.carregar_imagem(self.indice_atual - 1)

    def foto_proxima(self):
        self.carregar_imagem(self.indice_atual + 1)

    def setup_aba_anexos(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        self.list_anexos = QListWidget()
        self.list_anexos.itemDoubleClicked.connect(self.abrir_anexo)
        layout.addWidget(self.list_anexos)
        hbox = QHBoxLayout()
        btn_add = QPushButton("➕ Incluir")
        btn_add.clicked.connect(self.adicionar_anexo)
        btn_open = QPushButton("📂 Pasta")
        btn_open.clicked.connect(self.abrir_pasta_anexos)
        hbox.addWidget(btn_add)
        hbox.addWidget(btn_open)
        layout.addLayout(hbox)
        self.base_anexos_path = r"S:\geomap\geomap_imob\imobiliario_geomap"
        self.carregar_lista_anexos()

    def carregar_lista_anexos(self):
        self.list_anexos.clear()
        path = os.path.join(self.base_anexos_path, self.inscricao_limpa)
        if os.path.exists(path):
            for f in os.listdir(path):
                self.list_anexos.addItem(f"📄 {f}")

    def adicionar_anexo(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Selecionar Documento")
        if filename:
            dest = os.path.join(self.base_anexos_path, self.inscricao_limpa)
            if not os.path.exists(dest):
                os.makedirs(dest)
            shutil.copy2(filename, dest)
            self.carregar_lista_anexos()

    def abrir_anexo(self, item):
        path = os.path.join(self.base_anexos_path, self.inscricao_limpa, item.text().replace("📄 ", ""))
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def abrir_pasta_anexos(self):
        path = os.path.join(self.base_anexos_path, self.inscricao_limpa)
        if os.path.exists(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def setup_aba_historico(self, parent_widget):
        layout = QVBoxLayout(parent_widget)
        self.tabela_hist = QTableWidget()
        self.tabela_hist.setColumnCount(4)
        self.tabela_hist.setHorizontalHeaderLabels(["Inscrição", "Data", "Histórico", "Assunto"])
        layout.addWidget(self.tabela_hist)
        layers = QgsProject.instance().mapLayersByName("historico_imob_SMAR")
        if layers:
            req = QgsFeatureRequest().setFilterExpression(f"\"IdOrigem\" = '{self.inscricao_limpa}'")
            feats = list(layers[0].getFeatures(req))
            self.tabela_hist.setRowCount(len(feats))
            for i, f in enumerate(feats):
                self.tabela_hist.setItem(i, 0, QTableWidgetItem(str(f['IdOrigem'])))
                self.tabela_hist.setItem(i, 1, QTableWidgetItem(str(f['DtHistorico'])))
                self.tabela_hist.setItem(i, 2, QTableWidgetItem(str(f['Historico'])))
                self.tabela_hist.setItem(i, 3, QTableWidgetItem(str(f['Assunto'])))

    # --- LÓGICA DE IMPRESSÃO REUTILIZÁVEL ---
    def gerar_croqui_local(self):
        self._gerar_pdf_generico("A4 - Croqui de Imovel (IMOBILIARIO)", "CROQUI", self.combo_fundo.currentText())

    def gerar_ficha_local(self):
        self._gerar_pdf_generico("A4 - Ficha de Cadastro Imobiliario (IMOBILIARIO)", "FICHA_CAD", self.combo_fundo.currentText())

    def _gerar_pdf_generico(self, nome_layout, prefixo, camada_fundo):
        fid = self.feature.id()
        self.layer.selectByIds([fid])
        iface.mapCanvas().setExtent(self.feature.geometry().boundingBox().scaled(1.5))

        # 1. ATUALIZAR VISIBILIDADE DAS CAMADAS NA ÁRVORE
        root = QgsProject.instance().layerTreeRoot()
        for nome_camada in OPCOES_FUNDO.keys():
            camadas = QgsProject.instance().mapLayersByName(nome_camada)
            if camadas:
                node = root.findLayer(camadas[0].id())
                if node:
                    # Liga a camada escolhida e desliga as outras do dicionário
                    node.setItemVisibilityChecked(nome_camada == camada_fundo)
        
        iface.mapCanvas().refresh()

        # 2. CARREGAMENTO DO LAYOUT
        project = QgsProject.instance()
        manager = project.layoutManager()
        layout = manager.layoutByName(nome_layout)

        layout_vivo = False
        if layout:
            try:
                _ = layout.atlas()
                layout_vivo = True
            except RuntimeError:
                pass 

        if not layout_vivo:
            path_qpt = os.path.join(os.path.dirname(__file__), f"{nome_layout}.qpt")
            if not os.path.exists(path_qpt):
                QMessageBox.critical(self, "Erro", f"Modelo '{nome_layout}.qpt' não encontrado na pasta do plugin.")
                return
                
            layout = QgsPrintLayout(project)
            layout.initializeDefaults()
            
            with open(path_qpt, encoding='utf-8') as f:
                template_content = f.read()
                
            from PyQt5.QtXml import QDomDocument
            doc = QDomDocument()
            doc.setContent(template_content)
            layout.loadFromTemplate(doc, QgsReadWriteContext())
            
            if not manager.layoutByName(nome_layout):
                layout.setName(nome_layout)
                manager.addLayout(layout)

        # 3. ATUALIZAR O RÓTULO DO DATUM DINAMICAMENTE
        texto_dinamico = OPCOES_FUNDO.get(camada_fundo, "")
        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel):
                texto_atual = item.text()
                # Verifica se a caixa de texto contém o código do Datum
                if "[%item_variables('Mapa 1')" in texto_atual:
                    novo_texto = f"Datum:[%item_variables('Mapa 1')['map_crs_description']%]\n{texto_dinamico}"
                    item.setText(novo_texto)

        atlas = layout.atlas()
        atlas.setCoverageLayer(self.layer)
        atlas.setEnabled(True)
        atlas.setFilterExpression(f"$id = {fid}")

        path_save, _ = QFileDialog.getSaveFileName(self, "Salvar PDF", os.path.join(os.path.expanduser("~"), "Documents", f"{prefixo}_{self.inscricao_limpa}.pdf"), "PDF (*.pdf)")
        if path_save:
            if atlas.updateFeatures():
                atlas.beginRender()
                atlas.seekTo(0)
                exporter = QgsLayoutExporter(layout)
                if exporter.exportToPdf(path_save, QgsLayoutExporter.PdfExportSettings()) == QgsLayoutExporter.Success:
                    iface.messageBar().pushMessage("Sucesso", f"Arquivo gerado: {path_save}", level=0)
                    try: 
                        os.startfile(path_save)
                    except: 
                        pass
                else:
                    QMessageBox.critical(self, "Erro", "Falha na exportação do PDF.")
                atlas.endRender()
            else:
                QMessageBox.critical(self, "Erro", "Falha na renderização do Atlas.")

# ============================================================================
# 2. FERRAMENTA DE MAPA
# ============================================================================
class ToolSelecionarFicha(QgsMapTool):
    imovel_encontrado = pyqtSignal(object)
    def __init__(self, canvas, layer):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.setCursor(Qt.CrossCursor)
    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        rect = QgsGeometry.fromPointXY(point).buffer(self.canvas.mapUnitsPerPixel() * 2, 5).boundingBox()
        for f in self.layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            if f.geometry().contains(point): 
                self.imovel_encontrado.emit(f)
                break

# ============================================================================
# 3. INTERFACE PRINCIPAL (DOCK WIDGET)
# ============================================================================
class BuscaImovelDock(QDockWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🔍 Busca de Imóveis")
        self.setAllowedAreas(Qt.RightDockWidgetArea | Qt.LeftDockWidgetArea)
        self.main_widget = QWidget()
        self.setWidget(self.main_widget)
        self.setStyleSheet(MODERN_STYLE)
        
        self.layout = QVBoxLayout(self.main_widget)
        self.layout.setContentsMargins(10, 10, 10, 10)
        self.layout.setSpacing(10)
        
        self.setup_ui()
        self.tool_selecao = None

    def setup_ui(self):
        gb = QGroupBox("Parâmetros de Pesquisa")
        lb = QVBoxLayout(gb)
        
        self.combo = QComboBox()
        self.combo.addItems(["Inscrição", "Endereço", "CPF/CNPJ", "Proprietário"])
        
        self.input_busca = QLineEdit()
        self.input_busca.setPlaceholderText("Introduza o termo a procurar...")
        self.input_busca.returnPressed.connect(self.buscar)
        
        self.check_exata = QCheckBox("Busca Exata (Ignorar partes de palavras)")
        
        btn_buscar = QPushButton("🔎 Realizar Busca")
        btn_buscar.clicked.connect(self.buscar)

        lb.addWidget(QLabel("Filtrar por:"))
        lb.addWidget(self.combo)
        lb.addWidget(self.input_busca)
        lb.addWidget(self.check_exata)
        lb.addWidget(btn_buscar)
        self.layout.addWidget(gb)

        self.tabela = QTableWidget()
        self.tabela.setColumnCount(3)
        self.tabela.setHorizontalHeaderLabels(["Inscrição", "Endereço", "Proprietário"])
        self.tabela.setSortingEnabled(True) 
        
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive) 
        self.tabela.horizontalHeader().setStretchLastSection(True) 
        self.tabela.setColumnWidth(0, 100)
        self.tabela.setColumnWidth(1, 250)
        
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.doubleClicked.connect(lambda: self.acao_tabela(self.abrir_ficha_por_item))
        self.layout.addWidget(self.tabela)

        gb_acoes = QGroupBox("Ações Rápidas")
        layout_acoes = QVBoxLayout(gb_acoes)

        hbox_top = QHBoxLayout()
        btn_zoom = QPushButton("🎯 Zoom")
        btn_zoom.setObjectName("btnAcaoSecundaria")
        btn_zoom.clicked.connect(lambda: self.acao_tabela(self.zoom_para_imovel))
        
        btn_ficha = QPushButton("📄 Ver Ficha Completa")
        btn_ficha.clicked.connect(lambda: self.acao_tabela(self.abrir_ficha_por_item))
        
        hbox_top.addWidget(btn_zoom)
        hbox_top.addWidget(btn_ficha)
        layout_acoes.addLayout(hbox_top)
        
        btn_mapa = QPushButton("🖱️ Selecionar Clicando no Mapa")
        btn_mapa.setObjectName("btnAcaoSecundaria")
        btn_mapa.clicked.connect(self.ativar_ferramenta_mapa)
        layout_acoes.addWidget(btn_mapa)

        # --- SELETOR DE FUNDO PARA IMPRESSÃO RÁPIDA ---
        hbox_fundo = QHBoxLayout()
        lbl_fundo = QLabel("🖼️ Imagem:")
        lbl_fundo.setStyleSheet("font-weight: bold;")
        hbox_fundo.addWidget(lbl_fundo)
        
        self.combo_fundo_rapido = QComboBox()
        self.combo_fundo_rapido.addItems(list(OPCOES_FUNDO.keys()))
        hbox_fundo.addWidget(self.combo_fundo_rapido)
        layout_acoes.addLayout(hbox_fundo)
        # ----------------------------------------------

        hbox_print = QHBoxLayout()
        btn_croqui = QPushButton("🖨️ Croqui Rápido")
        btn_croqui.clicked.connect(lambda: self.acao_tabela(self.exportar_croqui))
        
        btn_ficha_rapida = QPushButton("📋 Ficha Rápida")
        btn_ficha_rapida.clicked.connect(lambda: self.acao_tabela(self.exportar_ficha))
        
        hbox_print.addWidget(btn_croqui)
        hbox_print.addWidget(btn_ficha_rapida)
        layout_acoes.addLayout(hbox_print)

        self.layout.addWidget(gb_acoes)

    def get_layer(self):
        nome_alvo = "IMOBILIARIO"
        layers = QgsProject.instance().mapLayersByName(nome_alvo)
        if layers: return layers[0]
        iface.messageBar().pushMessage("Erro", f"Camada base '{nome_alvo}' não encontrada.", level=2)
        return None

    def find_col(self, layer, keywords, exclude_keywords=[]):
        for f in layer.fields():
            fn_norm = normalize_str(f.name())
            is_excluded = False
            for exc in exclude_keywords:
                if exc in fn_norm:
                    is_excluded = True
                    break
            if is_excluded: continue
            for k in keywords:
                if k in fn_norm: return f.name()
        return None

    def aviso_coluna(self, nome):
        iface.messageBar().pushMessage("Erro", f"Coluna correspondente a '{nome}' não identificada.", level=2)

    def buscar(self):
        texto = self.input_busca.text().strip()
        layer = self.get_layer()
        if not layer or not texto: return

        tipo = self.combo.currentText()
        exata = self.check_exata.isChecked()
        
        self.tabela.setSortingEnabled(False)
        self.tabela.setRowCount(0)
        
        expr = ""
        if tipo == "Inscrição":
            col = self.find_col(layer, ['inscricao', 'im'])
            if not col: return self.aviso_coluna("Inscrição")
            op = "=" if exata else "ILIKE"
            val = f"'{texto}'" if exata else f"'%{texto}%'"
            expr = f"\"{col}\" {op} {val}"

        elif tipo == "Endereço":
            col = self.find_col(layer, ['bd_smar_imovel_endereco', 'endereco'])
            if not col: col = self.find_col(layer, ['logradouro', 'rua']) 
            if not col: return self.aviso_coluna("Endereço")
            expr = f"\"{col}\" ILIKE '%{texto}%'"

        elif tipo == "Proprietário":
            col = self.find_col(layer, ['proprietario', 'prop', 'nome'], exclude_keywords=['cpf', 'cnpj', 'doc'])
            if not col: return self.aviso_coluna("Proprietário")
            op = "=" if exata else "ILIKE"
            val = f"'{texto}'" if exata else f"'%{texto}%'"
            expr = f"\"{col}\" {op} {val}"

        elif tipo == "CPF/CNPJ":
            col = self.find_col(layer, ['cpf', 'cnpj', 'doc'])
            if not col: return self.aviso_coluna("CPF/CNPJ")
            nums = re.sub(r'[^0-9]', '', texto)
            if not nums: return
            op = "=" if exata else "LIKE"
            val = f"'{nums}'" if exata else f"'%{nums}%'"
            expr = f"regexp_replace(\"{col}\", '[^0-9]', '') {op} {val}"

        try:
            req = QgsFeatureRequest().setFilterExpression(expr)
            feats = list(layer.getFeatures(req))
            self.tabela.setRowCount(len(feats))
            
            c_insc = self.find_col(layer, ['inscricao', 'im'])
            c_prop = self.find_col(layer, ['proprietario', 'prop'], exclude_keywords=['cpf', 'cnpj', 'doc'])
            c_end  = self.find_col(layer, ['bd_smar_imovel_endereco', 'endereco'])
            if not c_end: c_end = self.find_col(layer, ['logradouro'])

            for r, f in enumerate(feats):
                v_insc = str(f[c_insc]) if c_insc else ""
                v_prop = str(f[c_prop]) if c_prop else ""
                v_end = str(f[c_end]) if c_end else ""

                self.tabela.setItem(r, 0, QTableWidgetItem(v_insc))
                self.tabela.setItem(r, 1, QTableWidgetItem(v_end))
                self.tabela.setItem(r, 2, QTableWidgetItem(v_prop))
                self.tabela.item(r, 0).setData(Qt.UserRole, f.id())

            self.tabela.setSortingEnabled(True)
            if not feats:
                iface.messageBar().pushMessage("Busca", "Nenhum resultado encontrado.", level=1)
        except Exception as e:
            iface.messageBar().pushMessage("Erro", f"Falha na consulta: {e}", level=2)

    def acao_tabela(self, func):
        sel = self.tabela.selectedItems()
        if not sel: 
            iface.messageBar().pushMessage("Atenção", "Selecione primeiro um imóvel na tabela.", level=1, duration=2)
            return
        func(sel[0])

    def zoom_para_imovel(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        layer.selectByIds([fid])
        box = layer.boundingBoxOfSelected()
        box.scale(1.5)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

    def abrir_ficha_por_item(self, item):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        self.abrir_dialogo_ficha(layer.getFeature(fid))

    def abrir_dialogo_ficha(self, feature):
        layer = self.get_layer()
        if not layer: return
        dialog = FichaImovelDialog(feature, layer, self)
        dialog.exec_()

    def ativar_ferramenta_mapa(self):
        layer = self.get_layer()
        if not layer: return
        self.tool_selecao = ToolSelecionarFicha(iface.mapCanvas(), layer)
        self.tool_selecao.imovel_encontrado.connect(self.abrir_dialogo_ficha)
        iface.mapCanvas().setMapTool(self.tool_selecao)
        iface.messageBar().pushMessage("Ferramenta Ativa", "Clique sobre o polígono do imóvel no mapa.", level=0, duration=3)

    # --- IMPRESSÃO RÁPIDA PELA TABELA ---
    def exportar_croqui(self, item):
        self._exportar_pdf_generico(item, "A4 - Croqui de Imovel (IMOBILIARIO)", "CROQUI", self.combo_fundo_rapido.currentText())

    def exportar_ficha(self, item):
        self._exportar_pdf_generico(item, "A4 - Ficha de Cadastro Imobiliario (IMOBILIARIO)", "FICHA_CAD", self.combo_fundo_rapido.currentText())

    def _exportar_pdf_generico(self, item, nome_layout, prefixo, camada_fundo):
        layer = self.get_layer()
        if not layer: return
        fid = self.tabela.item(item.row(), 0).data(Qt.UserRole)
        insc = self.tabela.item(item.row(), 0).text()
        
        feature = layer.getFeature(fid)
        iface.mapCanvas().setExtent(feature.geometry().boundingBox().scaled(1.2))
        
        # 1. ATUALIZAR VISIBILIDADE DAS CAMADAS NA ÁRVORE
        root = QgsProject.instance().layerTreeRoot()
        for nome_camada in OPCOES_FUNDO.keys():
            camadas = QgsProject.instance().mapLayersByName(nome_camada)
            if camadas:
                node = root.findLayer(camadas[0].id())
                if node:
                    node.setItemVisibilityChecked(nome_camada == camada_fundo)
                    
        iface.mapCanvas().refresh()
        
        # 2. CARREGAMENTO DO LAYOUT
        project = QgsProject.instance()
        manager = project.layoutManager()
        layout = manager.layoutByName(nome_layout)

        layout_vivo = False
        if layout:
            try:
                _ = layout.atlas()
                layout_vivo = True
            except RuntimeError:
                pass 

        if not layout_vivo:
            path_qpt = os.path.join(os.path.dirname(__file__), f"{nome_layout}.qpt")
            if not os.path.exists(path_qpt):
                iface.messageBar().pushMessage("Erro", f"Modelo '{nome_layout}.qpt' não encontrado na pasta do plugin.", level=2)
                return
                
            layout = QgsPrintLayout(project)
            layout.initializeDefaults()
            
            with open(path_qpt, encoding='utf-8') as f:
                template_content = f.read()
                
            from PyQt5.QtXml import QDomDocument
            doc = QDomDocument()
            doc.setContent(template_content)
            layout.loadFromTemplate(doc, QgsReadWriteContext())
            
            if not manager.layoutByName(nome_layout):
                layout.setName(nome_layout)
                manager.addLayout(layout)

        # 3. ATUALIZAR O RÓTULO DO DATUM DINAMICAMENTE
        texto_dinamico = OPCOES_FUNDO.get(camada_fundo, "")
        for item_layout in layout.items():
            if isinstance(item_layout, QgsLayoutItemLabel):
                texto_atual = item_layout.text()
                if "[%item_variables('Mapa 1')" in texto_atual:
                    novo_texto = f"Datum:[%item_variables('Mapa 1')['map_crs_description']%]\n{texto_dinamico}"
                    item_layout.setText(novo_texto)

        atlas = layout.atlas()
        atlas.setCoverageLayer(layer)
        atlas.setEnabled(True)
        atlas.setFilterExpression(f"$id = {fid}")
        
        insc_limpa = re.sub(r'[\\/*?:"<>|]', "", insc)
        path_inicial = os.path.join(os.path.expanduser("~"), "Documents", f"{prefixo}_{insc_limpa}.pdf")
        path, _ = QFileDialog.getSaveFileName(self, "Exportar PDF", path_inicial, "PDF (*.pdf)")
        
        if path:
            if atlas.updateFeatures():
                atlas.beginRender()
                atlas.seekTo(0)
                if QgsLayoutExporter(layout).exportToPdf(path, QgsLayoutExporter.PdfExportSettings()) == QgsLayoutExporter.Success:
                    iface.messageBar().pushMessage("Sucesso", "Exportado com sucesso.", level=0)
                    try: 
                        os.startfile(path)
                    except: 
                        pass
                else:
                    iface.messageBar().pushMessage("Erro", "Erro ao guardar ficheiro.", level=2)
                atlas.endRender()
            else:
                iface.messageBar().pushMessage("Erro", "Falha na preparação do Atlas.", level=2)