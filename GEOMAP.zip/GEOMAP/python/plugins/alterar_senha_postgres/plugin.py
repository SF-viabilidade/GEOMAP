# -*- coding: utf-8 -*-
import os
import psycopg2
from psycopg2 import sql
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QFormLayout, 
    QLineEdit, QComboBox, QDialogButtonBox, QMessageBox, QLabel
)
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsSettings, QgsApplication

class AlterarSenhaDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Alterar Senha PostgreSQL")
        self.resize(400, 250)
        
        # Layout Principal
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        # 1. Combobox de Conexões
        self.combo_conn = QComboBox()
        self.populate_connections()
        self.combo_conn.currentIndexChanged.connect(self.on_connection_change)
        form_layout.addRow("Conexão:", self.combo_conn)

        # 2. Usuário
        self.input_user = QLineEdit()
        form_layout.addRow("Usuário:", self.input_user)

        # 3. Senha Atual (Com máscara de senha)
        self.input_old_pass = QLineEdit()
        self.input_old_pass.setEchoMode(QLineEdit.Password)
        form_layout.addRow("Senha Atual:", self.input_old_pass)

        # 4. Nova Senha (Com máscara de senha)
        self.input_new_pass = QLineEdit()
        self.input_new_pass.setEchoMode(QLineEdit.Password)
        form_layout.addRow("Nova Senha:", self.input_new_pass)

        # 5. Confirmar Senha (Com máscara de senha)
        self.input_confirm_pass = QLineEdit()
        self.input_confirm_pass.setEchoMode(QLineEdit.Password)
        form_layout.addRow("Confirmar:", self.input_confirm_pass)

        layout.addLayout(form_layout)

        # Botões OK/Cancelar
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)

        # Preenche usuário inicial
        self.on_connection_change()

    def populate_connections(self):
        """Lê as conexões salvas no QGIS"""
        s = QgsSettings()
        s.beginGroup('/PostgreSQL/connections')
        conns = s.childGroups()
        s.endGroup()
        self.combo_conn.addItems(conns)

    def on_connection_change(self):
        """Tenta preencher o usuário se estiver salvo na conexão"""
        conn_name = self.combo_conn.currentText()
        s = QgsSettings()
        username = s.value(f'/PostgreSQL/connections/{conn_name}/username')
        if username:
            self.input_user.setText(username)
        else:
            self.input_user.clear()

    def get_connection_params(self, conn_name):
        """Extrai Host/Porta ou Service"""
        s = QgsSettings()
        base = f'/PostgreSQL/connections/{conn_name}'
        return {
            'host': s.value(f'{base}/host'),
            'port': s.value(f'{base}/port', '5432'),
            'database': s.value(f'{base}/database'),
            'service': s.value(f'{base}/service')
        }

    def accept(self):
        """Lógica executada ao clicar em OK"""
        conn_name = self.combo_conn.currentText()
        user = self.input_user.text()
        old_pass = self.input_old_pass.text()
        new_pass = self.input_new_pass.text()
        confirm_pass = self.input_confirm_pass.text()

        # Validações Básicas
        if not user or not old_pass or not new_pass:
            QMessageBox.warning(self, "Aviso", "Preencha todos os campos!")
            return

        if new_pass != confirm_pass:
            QMessageBox.warning(self, "Erro", "A nova senha e a confirmação não coincidem.")
            return

        if new_pass == old_pass:
            QMessageBox.warning(self, "Aviso", "A nova senha deve ser diferente da atual.")
            return

        # Preparar Conexão
        params = self.get_connection_params(conn_name)
        connect_args = {"user": user, "password": old_pass}

        # Lógica Host vs Service
        if params['host']:
            connect_args.update({
                "host": params['host'],
                "port": params['port'],
                "dbname": params['database']
            })
        elif params['service']:
            connect_args["service"] = params['service']
        else:
            QMessageBox.critical(self, "Erro", "Conexão sem Host nem Service definidos.")
            return

        # Executar Alteração
        try:
            conn = psycopg2.connect(**connect_args)
            conn.autocommit = True
            with conn.cursor() as cur:
                # Comando SQL Seguro
                query = sql.SQL("ALTER ROLE {} WITH PASSWORD %s").format(sql.Identifier(user))
                cur.execute(query, (new_pass,))
            conn.close()

            # Atualizar no QGIS (Opcional)
            s = QgsSettings()
            pass_key = f'/PostgreSQL/connections/{conn_name}/password'
            if s.contains(pass_key):
                s.setValue(pass_key, new_pass)
            
            QMessageBox.information(self, "Sucesso", "Senha alterada com sucesso!")
            super().accept() # Fecha a janela
            
        except psycopg2.Error as e:
            QMessageBox.critical(self, "Erro no Banco", f"Falha ao alterar senha:\n{e}")
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Erro inesperado:\n{e}")


class AlterarSenhaPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        # Configura Ícone
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # Cria Ação
        self.action = QAction(icon, "Alterar Senha PostgreSQL", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # Adiciona na Interface
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToDatabaseMenu("&Gerenciamento PostgreSQL", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginDatabaseMenu("&Gerenciamento PostgreSQL", self.action)

    def run(self):
        # Abre nossa janela personalizada (Dialog)
        dlg = AlterarSenhaDialog(self.iface.mainWindow())
        dlg.exec_()