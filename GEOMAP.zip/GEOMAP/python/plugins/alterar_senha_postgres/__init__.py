# -*- coding: utf-8 -*-

def classFactory(iface):
    from .plugin import AlterarSenhaPlugin
    return AlterarSenhaPlugin(iface)