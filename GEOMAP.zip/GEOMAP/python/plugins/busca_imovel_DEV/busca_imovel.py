# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt

# Importa a interface do plugin
from .interface_imovel import BuscaImovelDock

class BuscaImovelPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock_widget = None
        self.action = None

    def initGui(self):
        # --- CORREÇÃO DO ÍCONE ---
        # Identifica a pasta onde o plugin está instalado
        plugin_dir = os.path.dirname(__file__)
        # Localiza o arquivo icon.png dentro dessa pasta
        icon_path = os.path.join(plugin_dir, 'icon.png')
        
        # 1. Cria a Ação (Botão) usando o caminho absoluto do ícone
        self.action = QAction(
            QIcon(icon_path), 
            "Busca Imóveis", 
            self.iface.mainWindow()
        )
        self.action.setObjectName("BuscaImovelAction")
        self.action.setCheckable(True)
        
        # 2. Conecta o clique à função run
        self.action.triggered.connect(self.run)

        # 3. Adiciona o ícone na barra de ferramentas e no menu de complementos
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Busca Imóveis", self.action)

    def unload(self):
        # Remove o ícone e a entrada no menu ao desativar o plugin
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Busca Imóveis", self.action)
        
        # Remove a janela lateral (dock) se ela existir
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

    def run(self):
        """Lógica para abrir/fechar o painel lateral do plugin"""
        if not self.dock_widget:
            # Cria a instância da interface (passando o mainWindow como parent)
            self.dock_widget = BuscaImovelDock(self.iface.mainWindow())
            
            # Garante que o botão do ícone desmarque se o usuário fechar a janela no 'X'
            self.dock_widget.visibilityChanged.connect(self.action.setChecked)
            
            # Adiciona o dock na área lateral direita do QGIS
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)
        
        # Alterna visibilidade baseado no clique do botão
        if self.action.isChecked():
            self.dock_widget.show()
        else:
            self.dock_widget.hide()